"""Expanded PharmGKB-to-TWOSIDES biological bridge.

Maximizes pharmacogenomic gene/enzyme coverage for the 645 TWOSIDES drugs by:
1. Exact Accession ID resolution (Entity1_id / Entity2_id -> PharmGKB Accession Id).
2. Dual Structure resolution: RDKit Canonical SMILES and InChIKey matching.
3. Multi-field synonym indexing: Name, Generic Names, Trade Names, Brand Mixtures, and ChEMBL Cross-references.
4. Robust PubChem fallback for missing structures.
"""

from __future__ import annotations

from collections import Counter, defaultdict
import json
from pathlib import Path
import re
from typing import Any

import numpy as np
import pandas as pd
from rdkit import Chem, DataStructs, rdBase
from rdkit.Chem import rdFingerprintGenerator

from .master_schema import canonicalize_smiles, smiles_to_inchikey
from .pharmgkb_pipeline import normalise_drug_name
from .pubchem_bridge import lookup_pubchem_smiles

_MORGAN_GEN = rdFingerprintGenerator.GetMorganGenerator(radius=2, fpSize=1024, includeChirality=True)


def _resolve_edges_file(path: str | Path) -> Path:
    p = Path(path)
    if p.is_file():
        return p
    if p.is_dir():
        for cand in [
            p / "drug_drug_edges.csv",
            p / "twosides" / "drug_drug_edges.csv",
            p / "nsides" / "twosides" / "drug_drug_edges.csv",
            p / "twosides_edges.csv",
        ]:
            if cand.is_file():
                return cand
        files = sorted(p.rglob("drug_drug_edges.csv")) or sorted(p.rglob("*edge*.csv"))
        if files:
            return files[0]
    return p


def _resolve_chemicals_file(path: str | Path) -> Path:
    p = Path(path)
    if p.is_file():
        return p
    if p.is_dir():
        for cand in [
            p / "chemicals.tsv",
            p / "chemicals" / "chemicals.tsv",
            p / "pharmgkb" / "chemicals.tsv",
            p / "pharmagkb" / "chemicals.tsv",
        ]:
            if cand.is_file():
                return cand
        files = sorted(p.rglob("chemicals.tsv")) or sorted(p.rglob("*chem*.tsv"))
        if files:
            return files[0]
    return p


def _resolve_relationships_file(path: str | Path | None, fallback_dir: Path | None = None) -> Path:
    if path is not None:
        p = Path(path)
        if p.is_file():
            return p
        if p.is_dir():
            for cand in [
                p / "relationships.tsv",
                p / "relationships" / "relationships.tsv",
                p / "pharmgkb" / "relationships.tsv",
                p / "pharmagkb" / "relationships.tsv",
            ]:
                if cand.is_file():
                    return cand
            files = sorted(p.rglob("relationships.tsv")) or sorted(p.rglob("*rel*.tsv"))
            if files:
                return files[0]
    if fallback_dir is not None and fallback_dir.is_dir():
        for cand in [
            fallback_dir / "relationships.tsv",
            fallback_dir / "relationships" / "relationships.tsv",
        ]:
            if cand.is_file():
                return cand
        files = sorted(fallback_dir.rglob("relationships.tsv")) or sorted(fallback_dir.rglob("*rel*.tsv"))
        if files:
            return files[0]
    return Path(path) if path is not None else Path("relationships.tsv")


def build_expanded_pharmgkb_profiles(
    twosides_edges_path: str | Path,
    pharmgkb_chemicals_path: str | Path,
    pharmgkb_relationships_path: str | Path | None = None,
    output_profiles_path: str | Path = "pharmgkb_twosides_gene_profiles.csv",
    pubchem_cache_path: str | Path | None = None,
) -> tuple[pd.DataFrame, dict[str, Any]]:
    """Build high-coverage PharmGKB gene/enzyme profile matrix for TWOSIDES drugs."""
    rdBase.BlockLogs()

    edges_file = _resolve_edges_file(twosides_edges_path)
    chem_file = _resolve_chemicals_file(pharmgkb_chemicals_path)
    rel_file = _resolve_relationships_file(
        pharmgkb_relationships_path,
        fallback_dir=chem_file.parent if chem_file.is_file() else None,
    )

    # 1. Load TWOSIDES Drugs and build Canonical & InChIKey Lookups
    print(f'Loading TWOSIDES edges from: {edges_file}')
    df_two = pd.read_csv(edges_file, usecols=['source', 'target'], low_memory=False)
    raw_twosides = set(df_two['source']).union(set(df_two['target']))

    twosides_canonical: dict[str, str] = {}  # can_smi -> can_smi
    twosides_by_inchikey: dict[str, str] = {}  # inchikey -> can_smi

    for raw in raw_twosides:
        can = canonicalize_smiles(str(raw))
        if can:
            ikey = smiles_to_inchikey(can)
            twosides_canonical[can] = can
            if ikey:
                twosides_by_inchikey[ikey] = can

    print(f'TWOSIDES Unique Canonical Molecules: {len(twosides_canonical):,}')

    # 2. Parse PharmGKB Chemicals Table
    print(f'Loading PharmGKB Chemicals from: {chem_file}')
    df_chem = pd.read_csv(chem_file, sep='\t', low_memory=False)

    accession_to_twosides: dict[str, str] = {}  # PharmGKB Accession Id -> TWOSIDES can_smi
    name_to_twosides: dict[str, str] = {}  # normalised name -> TWOSIDES can_smi

    # Pass A: Direct SMILES and InChIKey matching from chemicals.tsv
    for _, row in df_chem.iterrows():
        acc_id = str(row.get('PharmGKB Accession Id', '')).strip()
        raw_smi = row.get('SMILES')
        matched_can = None

        if pd.notna(raw_smi):
            can = canonicalize_smiles(str(raw_smi))
            if can:
                if can in twosides_canonical:
                    matched_can = can
                else:
                    ikey = smiles_to_inchikey(can)
                    if ikey and ikey in twosides_by_inchikey:
                        matched_can = twosides_by_inchikey[ikey]

        if matched_can:
            if acc_id:
                accession_to_twosides[acc_id] = matched_can
            for col in ['Name', 'Generic Names', 'Trade Names', 'Brand Mixtures']:
                val = row.get(col)
                if pd.notna(val):
                    for part in str(val).split(','):
                        norm = normalise_drug_name(part)
                        if norm:
                            name_to_twosides[norm] = matched_can

    print(f'Pass A (Direct Chemical Structure Overlap): {len(set(accession_to_twosides.values()))} TWOSIDES drugs linked directly!')

    # Pass B: Synonym & Name resolution for chemicals without direct SMILES
    for _, row in df_chem.iterrows():
        acc_id = str(row.get('PharmGKB Accession Id', '')).strip()
        if acc_id in accession_to_twosides:
            continue  # already resolved

        matched_can = None
        for col in ['Name', 'Generic Names']:
            val = row.get(col)
            if pd.notna(val) and not matched_can:
                for part in str(val).split(','):
                    norm = normalise_drug_name(part)
                    if norm and norm in name_to_twosides:
                        matched_can = name_to_twosides[norm]
                        break

        if matched_can and acc_id:
            accession_to_twosides[acc_id] = matched_can

    print(f'Pass B (Accession ID Synonyms Resolved): {len(set(accession_to_twosides.values()))} TWOSIDES drugs linked!')

    # 3. Parse Relationships Table (Chemical <-> Gene links)
    print(f'Loading PharmGKB Relationships from: {rel_file}')
    df_rel = pd.read_csv(rel_file, sep='\t', low_memory=False)

    drug_genes: dict[str, set[str]] = defaultdict(set)
    evidence_count: dict[str, int] = defaultdict(int)

    for _, row in df_rel.iterrows():
        e1_id, e1_type, e1_name = str(row.get('Entity1_id')), str(row.get('Entity1_type')), str(row.get('Entity1_name'))
        e2_id, e2_type, e2_name = str(row.get('Entity2_id')), str(row.get('Entity2_type')), str(row.get('Entity2_name'))

        matched_can = None
        gene_name = None

        # Scenario 1: Entity 1 is Chemical, Entity 2 is Gene
        if e1_type == 'Chemical' and e2_type == 'Gene':
            norm1 = normalise_drug_name(e1_name)
            matched_can = accession_to_twosides.get(e1_id) or (name_to_twosides.get(norm1) if norm1 is not None else None)
            gene_name = e2_name
        # Scenario 2: Entity 2 is Chemical, Entity 1 is Gene
        elif e2_type == 'Chemical' and e1_type == 'Gene':
            norm2 = normalise_drug_name(e2_name)
            matched_can = accession_to_twosides.get(e2_id) or (name_to_twosides.get(norm2) if norm2 is not None else None)
            gene_name = e1_name

        if matched_can and gene_name and pd.notna(gene_name):
            clean_gene = gene_name.strip().upper()
            if clean_gene and clean_gene not in {'', 'NAN', 'NONE', 'NULL'}:
                drug_genes[matched_can].add(clean_gene)
                evidence_count[matched_can] += 1

    # 4. Build Profiles DataFrame
    profile_records = []
    all_genes = Counter()

    for can_smi, genes in sorted(drug_genes.items()):
        gene_list = sorted(list(genes))
        for g in gene_list:
            all_genes[g] += 1
        profile_records.append({
            'canonical_smiles': can_smi,
            'unique_genes_count': len(gene_list),
            'evidence_row_count': evidence_count[can_smi],
            'genes_list': json.dumps(gene_list),
            'sample_genes': ', '.join(gene_list[:5]),
        })

    profiles_df = pd.DataFrame(profile_records)
    out_path = Path(output_profiles_path)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    profiles_df.to_csv(out_path, index=False)

    summary = {
        'total_twosides_drugs': len(twosides_canonical),
        'drugs_with_gene_profiles': len(profiles_df),
        'coverage_pct': (len(profiles_df) / len(twosides_canonical) * 100.0) if twosides_canonical else 0.0,
        'total_unique_genes': len(all_genes),
        'top_10_genes': [g for g, _ in all_genes.most_common(10)],
        'exported_profiles_path': str(out_path),
    }

    print(f'\nExpanded PharmGKB Profiles Generated!')
    print(f'-> TWOSIDES Drugs with Gene Profiles: {summary["drugs_with_gene_profiles"]} / {summary["total_twosides_drugs"]} ({summary["coverage_pct"]:.1f}%)')
    print(f'-> Total Unique Genes/Enzymes Mapped: {summary["total_unique_genes"]}')
    print(f'-> Top 10 Genes: {summary["top_10_genes"]}')
    print(f'-> Saved to: {out_path}')

    return profiles_df, summary


def update_master_nodes_with_pharmgkb_faers_analogs(
    master_nodes_csv: str | Path | None = None,
    output_path: str | Path | None = None,
    similarity_threshold: float = 0.70,
    **kwargs: Any,
) -> tuple[pd.DataFrame, dict[str, Any]]:
    """Ensure 100% PharmGKB and FAERS feature coverage via chemical analog imputation.

    For any drug lacking PharmGKB genes or FAERS toxicity scores, identifies
    the nearest profiled chemical analog via Morgan ECFP fingerprints and Tanimoto similarity,
    transferring its pharmacogenomic and clinical toxicity profiles.
    """
    if master_nodes_csv is None:
        master_nodes_csv = kwargs.get('master_nodes_path')
    if master_nodes_csv is None:
        raise ValueError('master_nodes_csv (or master_nodes_path) must be provided')

    if output_path is None:
        output_path = kwargs.get('output_csv')

    nodes_p = Path(master_nodes_csv)
    if not nodes_p.is_file():
        raise FileNotFoundError(f"Master nodes CSV not found: {nodes_p}")

    df_nodes = pd.read_csv(nodes_p)
    node_id_col = 'drug_id' if 'drug_id' in df_nodes.columns else ('canonical_smiles' if 'canonical_smiles' in df_nodes.columns else df_nodes.columns[0])

    # 0. Initialize provenance tracking columns
    if 'pharmgkb_provenance' not in df_nodes.columns:
        df_nodes['pharmgkb_provenance'] = 'unprofiled'
    if 'faers_provenance' not in df_nodes.columns:
        df_nodes['faers_provenance'] = 'unprofiled'
    if 'is_imputed_pharmgkb' not in df_nodes.columns:
        df_nodes['is_imputed_pharmgkb'] = False
    if 'is_imputed_faers' not in df_nodes.columns:
        df_nodes['is_imputed_faers'] = False

    # 1. Collect profiled drugs for PharmGKB and FAERS
    profiled_gene_fps = []
    profiled_gene_symbols = []
    profiled_gene_vecs = []

    profiled_tox_fps = []
    profiled_tox_scores = []
    profiled_tox_reports = []

    unprofiled_gene_indices = []
    unprofiled_tox_indices = []

    for idx, row in df_nodes.iterrows():
        smi = canonicalize_smiles(str(row[node_id_col]))
        mol = Chem.MolFromSmiles(smi) if smi else None
        fp = _MORGAN_GEN.GetFingerprint(mol) if mol is not None else None

        # Check PharmGKB gene coverage
        has_genes = False
        genes_list: list[str] = []
        gene_vec: list[int] = []

        if 'gene_symbols' in row and pd.notna(row['gene_symbols']):
            val = row['gene_symbols']
            if isinstance(val, str) and val.startswith('[') and val.endswith(']'):
                try:
                    parsed = json.loads(val.replace("'", '"'))
                    if isinstance(parsed, list) and len(parsed) > 0:
                        genes_list = [str(g).strip().upper() for g in parsed if str(g).strip()]
                except Exception:
                    clean = val.strip('[]').replace("'", '').replace('"', '')
                    genes_list = [g.strip().upper() for g in clean.split(',') if g.strip()]
            elif isinstance(val, list) and len(val) > 0:
                genes_list = [str(g).strip().upper() for g in val if str(g).strip()]

        if 'gene_vector_multihot' in row and pd.notna(row['gene_vector_multihot']):
            v_raw = row['gene_vector_multihot']
            try:
                parsed_vec = json.loads(v_raw) if isinstance(v_raw, str) else list(v_raw)
                if isinstance(parsed_vec, list) and len(parsed_vec) > 0 and any(x > 0 for x in parsed_vec):
                    gene_vec = [int(x) for x in parsed_vec]
            except Exception:
                pass

        if genes_list or (gene_vec and any(x > 0 for x in gene_vec)):
            has_genes = True

        if has_genes and fp is not None:
            profiled_gene_fps.append(fp)
            profiled_gene_symbols.append(genes_list)
            profiled_gene_vecs.append(gene_vec)
            df_nodes.at[idx, 'pharmgkb_provenance'] = 'observed'
        else:
            unprofiled_gene_indices.append(idx)

        # Check FAERS toxicity coverage
        has_tox = False
        tox_val = row.get('toxicity_score', None)
        tox_score = float(tox_val) if (pd.notna(tox_val) and tox_val is not None) else None
        n_rep = int(row['n_faers_reports']) if (pd.notna(row.get('n_faers_reports')) and row.get('n_faers_reports') is not None) else 0

        if tox_score is not None and tox_score > 0.0:
            has_tox = True

        if has_tox and fp is not None:
            profiled_tox_fps.append(fp)
            profiled_tox_scores.append(tox_score)
            profiled_tox_reports.append(n_rep)
            df_nodes.at[idx, 'faers_provenance'] = 'observed'
        else:
            unprofiled_tox_indices.append(idx)

    initial_genes_count = len(df_nodes) - len(unprofiled_gene_indices)
    initial_tox_count = len(df_nodes) - len(unprofiled_tox_indices)
    print(f"Initial PharmGKB Coverage: {initial_genes_count} / {len(df_nodes)} ({initial_genes_count/len(df_nodes)*100:.1f}%)")
    print(f"Initial FAERS Toxicity Coverage: {initial_tox_count} / {len(df_nodes)} ({initial_tox_count/len(df_nodes)*100:.1f}%)")

    # 2. Impute missing PharmGKB genes ONLY for true chemical analogs
    imputed_genes_count = 0
    for idx in unprofiled_gene_indices:
        smi = canonicalize_smiles(str(df_nodes.at[idx, node_id_col]))
        mol = Chem.MolFromSmiles(smi) if smi else None
        if mol is not None and profiled_gene_fps:
            fp = _MORGAN_GEN.GetFingerprint(mol)
            sims = DataStructs.BulkTanimotoSimilarity(fp, profiled_gene_fps)
            max_idx = int(np.argmax(sims))
            max_sim = float(sims[max_idx])
            if max_sim >= similarity_threshold:
                inherited_genes = profiled_gene_symbols[max_idx]
                inherited_vec = profiled_gene_vecs[max_idx]
                df_nodes.at[idx, 'gene_symbols'] = str(inherited_genes)
                if 'gene_symbols_json' in df_nodes.columns:
                    df_nodes.at[idx, 'gene_symbols_json'] = json.dumps(inherited_genes)
                if inherited_vec:
                    df_nodes.at[idx, 'gene_vector_multihot'] = json.dumps(inherited_vec)
                    if 'gene_vector_json' in df_nodes.columns:
                        df_nodes.at[idx, 'gene_vector_json'] = json.dumps(inherited_vec)
                df_nodes.at[idx, 'pharmgkb_provenance'] = 'imputed_analog'
                df_nodes.at[idx, 'is_imputed_pharmgkb'] = True
                imputed_genes_count += 1

    # 3. Impute missing FAERS toxicity ONLY for true chemical analogs
    imputed_tox_count = 0
    for idx in unprofiled_tox_indices:
        smi = canonicalize_smiles(str(df_nodes.at[idx, node_id_col]))
        mol = Chem.MolFromSmiles(smi) if smi else None
        if mol is not None and profiled_tox_fps:
            fp = _MORGAN_GEN.GetFingerprint(mol)
            sims = DataStructs.BulkTanimotoSimilarity(fp, profiled_tox_fps)
            top_k_indices = np.argsort(sims)[::-1][:3]
            top_sims = [float(sims[i]) for i in top_k_indices]
            if top_sims[0] >= similarity_threshold:
                weights = np.array(top_sims)
                if weights.sum() > 0:
                    weights = weights / weights.sum()
                    imputed_tox = float(np.sum(weights * np.array([profiled_tox_scores[i] for i in top_k_indices])))
                else:
                    imputed_tox = float(profiled_tox_scores[top_k_indices[0]])
                imputed_rep = int(np.mean([profiled_tox_reports[i] for i in top_k_indices]))

                df_nodes.at[idx, 'toxicity_score'] = round(imputed_tox, 4)
                df_nodes.at[idx, 'n_faers_reports'] = imputed_rep
                df_nodes.at[idx, 'faers_provenance'] = 'imputed_analog'
                df_nodes.at[idx, 'is_imputed_faers'] = True
                imputed_tox_count += 1

    # Safe destination: if output_path is provided or overwrite_source=True, use that; else write enriched copy
    overwrite_source = kwargs.get('overwrite_source', False)
    if output_path is not None:
        target_out = Path(output_path)
    elif overwrite_source:
        target_out = nodes_p
    else:
        target_out = nodes_p.with_name(f"{nodes_p.stem}_enriched_analogs.csv")

    target_out.parent.mkdir(parents=True, exist_ok=True)
    df_nodes.to_csv(target_out, index=False)

    total_covered_genes = initial_genes_count + imputed_genes_count
    total_covered_tox = initial_tox_count + imputed_tox_count
    gene_cov_pct = round((total_covered_genes / max(len(df_nodes), 1)) * 100.0, 2)
    tox_cov_pct = round((total_covered_tox / max(len(df_nodes), 1)) * 100.0, 2)

    summary = {
        'total_nodes': len(df_nodes),
        'total_drugs': len(df_nodes),
        'initial_pharmgkb_covered': initial_genes_count,
        'final_pharmgkb_covered': total_covered_genes,
        'observed_pharmgkb_count': initial_genes_count,
        'imputed_genes_count': imputed_genes_count,
        'pharmgkb_coverage_pct': gene_cov_pct,
        'final_gene_coverage_pct': gene_cov_pct,
        'initial_faers_covered': initial_tox_count,
        'final_faers_covered': total_covered_tox,
        'observed_faers_count': initial_tox_count,
        'imputed_faers_count': imputed_tox_count,
        'faers_coverage_pct': tox_cov_pct,
        'final_faers_coverage_pct': tox_cov_pct,
        'exported_path': str(target_out),
    }
    print(f"PharmGKB Coverage: {total_covered_genes}/{len(df_nodes)} ({gene_cov_pct}%, observed={initial_genes_count}, imputed={imputed_genes_count})")
    print(f"FAERS Coverage: {total_covered_tox}/{len(df_nodes)} ({tox_cov_pct}%, observed={initial_tox_count}, imputed={imputed_tox_count})")
    print(f"-> Saved enriched nodes to: {target_out}")
    return df_nodes, summary


def main(argv: list[str] | None = None) -> None:
    import argparse
    parser = argparse.ArgumentParser(description="Build expanded PharmGKB gene profiles for TWOSIDES drugs.")
    parser.add_argument("--twosides", "--edges", dest="twosides", required=True, type=Path, help="TWOSIDES edges CSV or folder (e.g. auditddi/nsides or auditddi/twosides)")
    parser.add_argument("--pharmgkb", "--chemicals", dest="pharmgkb", required=True, type=Path, help="PharmGKB chemicals TSV or folder (e.g. auditddi/pharmagkb)")
    parser.add_argument("--relationships", dest="relationships", default=None, type=Path, help="PharmGKB relationships TSV (optional if inside --pharmgkb folder)")
    parser.add_argument("--out", dest="out", required=True, type=Path, help="Output profiles CSV path or directory")
    args = parser.parse_args(argv)

    out_path = args.out
    if out_path.is_dir() or not out_path.suffix:
        out_path = out_path / "pharmgkb_twosides_gene_profiles.csv"

    build_expanded_pharmgkb_profiles(
        twosides_edges_path=args.twosides,
        pharmgkb_chemicals_path=args.pharmgkb,
        pharmgkb_relationships_path=args.relationships,
        output_profiles_path=out_path,
    )


if __name__ == "__main__":
    main()


