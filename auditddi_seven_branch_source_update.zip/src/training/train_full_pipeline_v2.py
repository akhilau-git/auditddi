"""Reproducible Colab training pipeline for the research-only AuditDDI GNN.

This script intentionally keeps ChemBERTa disabled. It saves all run-specific
artifacts to Google Drive so a later paper result can be traced to its input
data, split manifests, checkpoint, predictions, and plots.
"""

from __future__ import annotations

import hashlib
from importlib.metadata import PackageNotFoundError, version as distribution_version
import json
import os
from pathlib import Path
import platform
import random
import shutil
import subprocess
import sys
import tempfile
import time
from datetime import datetime, timezone
from typing import Any, cast, Literal, overload

import numpy as np
import pandas as pd
import torch
from torch import nn
try:
    import torch.serialization
    if hasattr(torch.serialization, 'add_safe_globals'):
        _safe_globals: list[Any] = [np.ndarray, np.dtype]
        try:
            import numpy._core.multiarray as _np_core
            _safe_globals.append(_np_core._reconstruct)
        except Exception:
            pass
        try:
            import numpy.core.multiarray as _np_core_legacy
            _safe_globals.append(_np_core_legacy._reconstruct)
        except Exception:
            pass
        torch.serialization.add_safe_globals(_safe_globals)
except Exception:
    pass
from matplotlib import pyplot as plt
from sklearn.calibration import calibration_curve
from sklearn.metrics import (
    average_precision_score,
    brier_score_loss,
    confusion_matrix,
    f1_score,
    matthews_corrcoef,
    precision_recall_curve,
    precision_score,
    recall_score,
    roc_auc_score,
    roc_curve,
)
from torch_geometric.data import Batch, Dataset
from torch_geometric.loader import DataLoader


PROJECT_ROOT = Path(__file__).resolve().parents[2]
REPOSITORY_SRC = PROJECT_ROOT / 'src'
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))
if str(REPOSITORY_SRC) not in sys.path:
    sys.path.insert(0, str(REPOSITORY_SRC))

from data_prep.path_resolver import (
    resolve_data_base,
    resolve_results_base as _resolve_results_base_helper,
    resolve_dataset_subpath,
    get_auditddi_env,
)

# Importing this module supplies utilities to the unit tests and experiment
# launchers.  Dataset discovery must remain strict when training starts, but
# an absent Drive mount must not make those utilities impossible to import.
DATA_BASE_RESOLUTION_ERROR: FileNotFoundError | None = None
try:
    DRIVE_BASE = resolve_data_base()
except FileNotFoundError as error:
    DATA_BASE_RESOLUTION_ERROR = error
    DRIVE_BASE = Path(get_auditddi_env('DATA_BASE', PROJECT_ROOT / 'data'))

from data_prep.prepare_twosides import (
    FEATURE_SCHEMA_LEGACY,
    FEATURE_SCHEMA_RICH,
    LEGACY_NUM_ATOM_FEATURES,
    NUM_BOND_FEATURES,
    RICH_NUM_ATOM_FEATURES,
    graph_compatibility_reason as source_graph_compatibility_reason,
    smiles_to_graph,
)
from data_prep.molecular_motifs import (
    MOTIF_FEATURE_DIM,
    MOTIF_FEATURE_NAMES,
    MOTIF_SCHEMA_SMARTS_COUNTS_V1,
    motif_metadata,
)
from data_prep.pubchem_bridge import canonicalize, resolve_toxicity_bridge
from data_prep.splits import (
    build_binary_pair_dataset,
    create_split_aware_binary_splits,
    create_splits,
    deduplicate_unordered_pairs,
)
from models.ddi_model import (
    MODEL_ARCHITECTURE_EDGE_AWARE,
    MODEL_ARCHITECTURE_LEGACY,
    MODEL_ARCHITECTURE_MOTIF_EDGE_AWARE,
    MODEL_ARCHITECTURE_CROSS_ATTENTION_EDGE_AWARE,
    MODEL_ARCHITECTURE_GRAPH_FP_FUSION,
    MODEL_ARCHITECTURE_AUDITDDI_MEMORY,
    MODEL_ARCHITECTURE_MULTIMODAL,
    MODEL_ARCHITECTURE_SEVEN_BRANCH,
    PxDDIModel,
    AuditDDIModel,
)
from models.neighbor_memory import AuditableNeighborMemory
from models.seven_branch_ddi import (
    SEVEN_BRANCH_ARCHITECTURE,
    SEVEN_BRANCH_NAMES,
    SevenBranchDDIModel,
)
from models.calibration import (
    apply_calibrator,
    expected_calibration_error,
    fit_platt_calibrator,
)
from models.candidate_explainability import (
    EXPLANATION_LIMITATIONS,
    EXPLANATION_METHOD,
    explain_pair_with_occlusion,
    render_occlusion_svg,
    select_representative_indices,
)
from models.applicability_domain import MorganApplicabilityDomain
from models.encoder import EdgeAwareMolecularEncoder
from models.encoder_pretraining import load_pretrained_edge_aware_encoder
from evaluation.pair_applicability_domain import PairApplicabilityDomain
from evaluation.degradation_audit import DegradationAudit
from evaluation.reliability_diagram import plot_reliability_diagram
from models.uncertainty import (
    conformal_prediction_sets,
    fit_split_conformal_binary,
    predictive_entropy,
    summarize_conformal_test_labels,
)
from evaluation.ddi_metrics import (
    bootstrap_confidence_intervals,
    calculate_binary_metrics,
    evaluation_metric_table,
    save_confident_error_analysis,
    selective_prediction_summary,
    structural_similarity_slices,
)


def _positive_int_from_environment(name: str, default: int) -> int:
    suffix = name.replace('AUDITDDI_', '').replace('PXDDI_', '')
    raw = get_auditddi_env(suffix, default)
    value = int(raw)
    if value <= 0:
        raise ValueError(f'{name} must be a positive integer.')
    return value


def _non_negative_int_from_environment(name: str, default: int) -> int:
    suffix = name.replace('AUDITDDI_', '').replace('PXDDI_', '')
    raw = get_auditddi_env(suffix, default)
    value = int(raw)
    if value < 0:
        raise ValueError(f'{name} must be zero or a positive integer.')
    return value


def _boolean_from_environment(name: str, default: bool) -> bool:
    suffix = name.replace('AUDITDDI_', '').replace('PXDDI_', '')
    value = get_auditddi_env(suffix, default)
    if value is None:
        return default
    if isinstance(value, bool):
        return value
    normalized = str(value).strip().lower()
    if normalized in {'1', 'true', 'yes'}:
        return True
    if normalized in {'0', 'false', 'no'}:
        return False
    raise ValueError(f'{name} must be one of true/false, yes/no, or 1/0.')


def _open_unit_interval_from_environment(name: str, default: float) -> float:
    suffix = name.replace('AUDITDDI_', '').replace('PXDDI_', '')
    value = float(get_auditddi_env(suffix, default))
    if not 0 < value < 1:
        raise ValueError(f'{name} must lie strictly between zero and one.')
    return value


def _closed_unit_interval_from_environment(name: str, default: float) -> float:
    suffix = name.replace('AUDITDDI_', '').replace('PXDDI_', '')
    value = float(get_auditddi_env(suffix, default))
    if not 0 <= value <= 1:
        raise ValueError(f'{name} must lie between zero and one.')
    return value


def resolve_results_base(
    configured_path: str | Path | None = None,
    data_base: Path = DRIVE_BASE,
) -> Path:
    """Choose a writable output root independently of a shared data shortcut."""
    return _resolve_results_base_helper(configured_path)


# ``PXDDI_SEED`` remains the backwards-compatible one-knob default.  Ensemble
# training can override the model and split seeds independently so its members
# genuinely differ while evaluating exactly the same rows.
SEED = _positive_int_from_environment('AUDITDDI_SEED', 42)
MODEL_SEED = _positive_int_from_environment('AUDITDDI_MODEL_SEED', SEED)
SPLIT_SEED = _positive_int_from_environment('AUDITDDI_SPLIT_SEED', SEED)
DATA_CAP = _positive_int_from_environment('AUDITDDI_DATA_CAP', 200000)
EPOCHS = _positive_int_from_environment('AUDITDDI_EPOCHS', 200)
RESUME_CHECKPOINT_PATH = get_auditddi_env('RESUME_CHECKPOINT_PATH')
RESUME_HISTORY_PATH = get_auditddi_env('RESUME_HISTORY_PATH')
RESUME_AFTER_EPOCH = _non_negative_int_from_environment(
    'AUDITDDI_RESUME_AFTER_EPOCH', 0
)
if RESUME_CHECKPOINT_PATH and RESUME_AFTER_EPOCH <= 0:
    raise ValueError(
        'AUDITDDI_RESUME_AFTER_EPOCH must be set to the last completed epoch '
        'when AUDITDDI_RESUME_CHECKPOINT_PATH is configured.'
    )
if RESUME_CHECKPOINT_PATH and RESUME_AFTER_EPOCH >= EPOCHS:
    raise ValueError(
        'AUDITDDI_RESUME_AFTER_EPOCH must be lower than AUDITDDI_EPOCHS so '
        'there are epochs left to run.'
    )
HIDDEN_CHANNELS = _positive_int_from_environment('AUDITDDI_HIDDEN_CHANNELS', 128)
BATCH_SIZE = _positive_int_from_environment('AUDITDDI_BATCH_SIZE', 128)
EARLY_STOPPING_PATIENCE = _non_negative_int_from_environment(
    'AUDITDDI_EARLY_STOPPING_PATIENCE', 30
)
EARLY_STOPPING_MIN_EPOCHS = _positive_int_from_environment(
    'AUDITDDI_EARLY_STOPPING_MIN_EPOCHS', 40
)
if EARLY_STOPPING_MIN_EPOCHS > EPOCHS:
    raise ValueError('AUDITDDI_EARLY_STOPPING_MIN_EPOCHS must not exceed PXDDI_EPOCHS.')
MODEL_SELECTION_VALIDATION_FRACTION = _open_unit_interval_from_environment(
    'AUDITDDI_MODEL_SELECTION_VALIDATION_FRACTION', 0.5
)
NEGATIVE_SAMPLING_STRATEGY = os.environ.get('AUDITDDI_NEGATIVE_SAMPLING_STRATEGY', 'degree_matched')
NEGATIVE_SAMPLING_PROTOCOL = os.environ.get(
    'AUDITDDI_NEGATIVE_SAMPLING_PROTOCOL', 'split_aware_standard_v1'
).strip().lower()
if NEGATIVE_SAMPLING_PROTOCOL not in {'split_aware_standard_v1', 'legacy_pre_split_v1'}:
    raise ValueError(
        'AUDITDDI_NEGATIVE_SAMPLING_PROTOCOL must be split_aware_standard_v1 or '
        'legacy_pre_split_v1.'
    )
NEGATIVE_LABEL_MEANING = (
    'unreported_twosides_split_aware_sampled'
    if NEGATIVE_SAMPLING_PROTOCOL == 'split_aware_standard_v1'
    else f'unreported_twosides_sampled_{NEGATIVE_SAMPLING_STRATEGY}'
)
USE_CHEMBERTA = False
MODEL_ARCHITECTURE = os.environ.get(
    'AUDITDDI_MODEL_ARCHITECTURE', MODEL_ARCHITECTURE_EDGE_AWARE
)
if MODEL_ARCHITECTURE not in {
    MODEL_ARCHITECTURE_LEGACY,
    MODEL_ARCHITECTURE_EDGE_AWARE,
    MODEL_ARCHITECTURE_MOTIF_EDGE_AWARE,
    MODEL_ARCHITECTURE_CROSS_ATTENTION_EDGE_AWARE,
    MODEL_ARCHITECTURE_GRAPH_FP_FUSION,
    MODEL_ARCHITECTURE_AUDITDDI_MEMORY,
    MODEL_ARCHITECTURE_MULTIMODAL,
    MODEL_ARCHITECTURE_SEVEN_BRANCH,
}:
    raise ValueError(f'Unsupported AUDITDDI_MODEL_ARCHITECTURE: {MODEL_ARCHITECTURE}.')
USES_EDGE_FEATURES = MODEL_ARCHITECTURE in {
    MODEL_ARCHITECTURE_EDGE_AWARE,
    MODEL_ARCHITECTURE_MOTIF_EDGE_AWARE,
    MODEL_ARCHITECTURE_CROSS_ATTENTION_EDGE_AWARE,
    MODEL_ARCHITECTURE_GRAPH_FP_FUSION,
    MODEL_ARCHITECTURE_AUDITDDI_MEMORY,
    MODEL_ARCHITECTURE_MULTIMODAL,
    MODEL_ARCHITECTURE_SEVEN_BRANCH,
}
USE_MOTIF_FEATURES = MODEL_ARCHITECTURE == MODEL_ARCHITECTURE_MOTIF_EDGE_AWARE
USE_FINGERPRINT_FEATURES = MODEL_ARCHITECTURE in {
    MODEL_ARCHITECTURE_GRAPH_FP_FUSION,
    MODEL_ARCHITECTURE_AUDITDDI_MEMORY,
    MODEL_ARCHITECTURE_MULTIMODAL,
    MODEL_ARCHITECTURE_SEVEN_BRANCH,
}
USE_NEIGHBOR_MEMORY = MODEL_ARCHITECTURE == MODEL_ARCHITECTURE_AUDITDDI_MEMORY
USE_SEVEN_SOURCE_FEATURES = MODEL_ARCHITECTURE == MODEL_ARCHITECTURE_MULTIMODAL
USE_SEVEN_BRANCH_MODEL = MODEL_ARCHITECTURE == MODEL_ARCHITECTURE_SEVEN_BRANCH
SEVEN_SOURCE_FEATURE_DIM = 51
SEVEN_BRANCH_FEATURE_BUNDLE = Path(os.environ.get(
    'AUDITDDI_SEVEN_BRANCH_FEATURE_BUNDLE',
    str(DRIVE_BASE / 'processed' / 'auditddi_v3' / 'seven_branch_features.npz'),
))
SEVEN_BRANCH_DIMENSIONS: dict[str, int] = {}
if USE_SEVEN_SOURCE_FEATURES or USE_SEVEN_BRANCH_MODEL:
    NEGATIVE_LABEL_MEANING = 'not_reported_in_twosides_or_matched_ddinter_sampled_unknown'
USE_CROSS_DRUG_ATTENTION = (
    MODEL_ARCHITECTURE == MODEL_ARCHITECTURE_CROSS_ATTENTION_EDGE_AWARE
)
MOTIF_HIDDEN_CHANNELS = _positive_int_from_environment(
    'AUDITDDI_MOTIF_HIDDEN_CHANNELS', 32
)
FEATURE_SCHEMA = (
    FEATURE_SCHEMA_RICH
    if USES_EDGE_FEATURES
    else FEATURE_SCHEMA_LEGACY
)
INPUT_FEATURE_DIM = (
    RICH_NUM_ATOM_FEATURES
    if FEATURE_SCHEMA == FEATURE_SCHEMA_RICH
    else LEGACY_NUM_ATOM_FEATURES
)
USE_TOXICITY_PAIR_FEATURES = _boolean_from_environment(
    'AUDITDDI_USE_TOXICITY_PAIR_FEATURES', False
)
TOXICITY_LOSS_WEIGHT = float(os.environ.get('AUDITDDI_TOXICITY_LOSS_WEIGHT', '0.0'))
if TOXICITY_LOSS_WEIGHT < 0:
    raise ValueError('AUDITDDI_TOXICITY_LOSS_WEIGHT must be non-negative.')
USE_PDB_ENCODER = MODEL_ARCHITECTURE == MODEL_ARCHITECTURE_MULTIMODAL
USE_CLINICAL_TOXICITY = MODEL_ARCHITECTURE == MODEL_ARCHITECTURE_MULTIMODAL
EVALUATION_PROTOCOL = os.environ.get('AUDITDDI_EVALUATION_PROTOCOL', 'standard').strip().lower()
if EVALUATION_PROTOCOL not in {'standard', 'scaffold_disjoint'}:
    raise ValueError("AUDITDDI_EVALUATION_PROTOCOL must be 'standard' or 'scaffold_disjoint'.")
BOOTSTRAP_RESAMPLES = _non_negative_int_from_environment('AUDITDDI_BOOTSTRAP_RESAMPLES', 1000)
ERROR_ANALYSIS_MAX_ROWS = _positive_int_from_environment('AUDITDDI_ERROR_ANALYSIS_MAX_ROWS', 100)

# Keep the module importable for unit tests and CI without a mounted Drive.
# ``main`` raises the saved resolver error before training or evaluation can
# read either placeholder path.
if DATA_BASE_RESOLUTION_ERROR is None:
    # Prefer the versioned, audited Drive preparation produced during the
    # user's current workflow. The old raw-folder edge CSV remains a fallback
    # for earlier checkouts, but must not silently override the audited table.
    PREPARED_TWOSIDES = DRIVE_BASE / 'processed' / 'twosides_v1'
    TWOSIDES_PARQUET = PREPARED_TWOSIDES / 'twosides_clean.parquet'
    TWOSIDES_DRUGS = PREPARED_TWOSIDES / 'drugs_clean.csv'
    SOURCE_BUNDLE = DRIVE_BASE / 'processed' / 'auditddi_v2'
    SOURCE_FEATURE_MATRIX = SOURCE_BUNDLE / 'source_feature_matrix.npz'
    SOURCE_BUNDLE_MANIFEST = SOURCE_BUNDLE / 'source_bundle_manifest.json'
    SOURCE_AUDIT = DRIVE_BASE / 'processed' / 'auditddi_v1'
    DDINTER_MATCH_AUDIT = SOURCE_AUDIT / 'ddinter_pubchem_match_audit.csv'
    TWOSIDES_EDGES = resolve_dataset_subpath(DRIVE_BASE, 'twosides', 'drug_drug_edges.csv')
    TOXICITY_BRIDGE = resolve_dataset_subpath(DRIVE_BASE, 'checkpoints', 'toxicity_smiles_bridge.csv')
else:
    PREPARED_TWOSIDES = DRIVE_BASE / 'processed' / 'twosides_v1'
    TWOSIDES_PARQUET = PREPARED_TWOSIDES / 'twosides_clean.parquet'
    TWOSIDES_DRUGS = PREPARED_TWOSIDES / 'drugs_clean.csv'
    SOURCE_BUNDLE = DRIVE_BASE / 'processed' / 'auditddi_v2'
    SOURCE_FEATURE_MATRIX = SOURCE_BUNDLE / 'source_feature_matrix.npz'
    SOURCE_BUNDLE_MANIFEST = SOURCE_BUNDLE / 'source_bundle_manifest.json'
    SOURCE_AUDIT = DRIVE_BASE / 'processed' / 'auditddi_v1'
    DDINTER_MATCH_AUDIT = SOURCE_AUDIT / 'ddinter_pubchem_match_audit.csv'
    TWOSIDES_EDGES = DRIVE_BASE / 'twosides' / 'drug_drug_edges.csv'
    TOXICITY_BRIDGE = DRIVE_BASE / 'checkpoints' / 'toxicity_smiles_bridge.csv'
RESULTS_BASE = resolve_results_base()
DEFAULT_CHECKPOINT_PATH = (
    RESULTS_BASE / 'checkpoints' / 'auditddi_model.pt'
    if MODEL_ARCHITECTURE == MODEL_ARCHITECTURE_LEGACY
    else RESULTS_BASE / 'checkpoints' / 'candidates' / (
        'auditddi_memory_fusion_candidate.pt'
        if USE_NEIGHBOR_MEMORY
        else 'auditddi_seven_branch_candidate.pt'
        if USE_SEVEN_BRANCH_MODEL
        else 'auditddi_graph_fp_fusion_candidate.pt'
        if USE_FINGERPRINT_FEATURES
        else 'auditddi_motif_edge_aware_candidate.pt'
        if USE_MOTIF_FEATURES
        else 'auditddi_cross_attention_edge_aware_candidate.pt'
        if USE_CROSS_DRUG_ATTENTION
        else 'auditddi_edge_aware_candidate.pt'
    )
)
CHECKPOINT_PATH = Path(get_auditddi_env('CHECKPOINT_PATH', DEFAULT_CHECKPOINT_PATH))
CHECKPOINT_PATH_WAS_EXPLICITLY_CONFIGURED = (
    'AUDITDDI_CHECKPOINT_PATH' in os.environ or 'PXDDI_CHECKPOINT_PATH' in os.environ
)
PRETRAINED_ENCODER_PATH = (
    Path(get_auditddi_env('PRETRAINED_ENCODER_PATH'))
    if get_auditddi_env('PRETRAINED_ENCODER_PATH')
    else None
)
if PRETRAINED_ENCODER_PATH is not None and not USES_EDGE_FEATURES:
    raise ValueError(
        'AUDITDDI_PRETRAINED_ENCODER_PATH can initialize only a rich edge-aware '
        'candidate, not the legacy GAT architecture.'
    )
RUN_ID = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')
ARTIFACTS_BASE = Path(get_auditddi_env('ARTIFACTS_BASE', RESULTS_BASE / 'artifacts'))
RUN_ARTIFACTS_DIR = ARTIFACTS_BASE / f'run_{RUN_ID}'
LATEST_RESULTS_DIR = Path(
    get_auditddi_env('LATEST_RESULTS_DIR', RESULTS_BASE / 'latest_results')
)
PUBLISH_LATEST_RESULTS = _boolean_from_environment('AUDITDDI_PUBLISH_LATEST_RESULTS', True)
EVALUATE_ONLY = _boolean_from_environment('AUDITDDI_EVALUATE_ONLY', False)
if EVALUATE_ONLY and not CHECKPOINT_PATH_WAS_EXPLICITLY_CONFIGURED:
    raise ValueError(
        'AUDITDDI_EVALUATE_ONLY requires an explicit AUDITDDI_CHECKPOINT_PATH. '
        'Refusing to select an arbitrary candidate checkpoint.'
    )
RUN_CANDIDATE_EXPLANATIONS = _boolean_from_environment(
    'AUDITDDI_RUN_CANDIDATE_EXPLANATIONS', False
)
EXPLANATION_SAMPLES_PER_SPLIT = _positive_int_from_environment(
    'AUDITDDI_EXPLANATION_SAMPLES_PER_SPLIT', 4
)
EXPLANATION_TOP_K = _positive_int_from_environment('AUDITDDI_EXPLANATION_TOP_K', 5)
CONFORMAL_ALPHA = _open_unit_interval_from_environment('AUDITDDI_CONFORMAL_ALPHA', 0.1)
APPLICABILITY_DOMAIN_MINIMUM_SIMILARITY = _closed_unit_interval_from_environment(
    'AUDITDDI_APPLICABILITY_DOMAIN_MINIMUM_SIMILARITY', 0.4
)
DEVICE = torch.device('cuda' if torch.cuda.is_available() else 'cpu')


def set_reproducibility(seed: int) -> None:
    """Set every supported random seed without making GPU execution fail hard."""
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False
    torch.use_deterministic_algorithms(True, warn_only=True)


def get_file_hash(path: str | Path) -> str:
    """Return a complete SHA-256 digest without loading a whole file into RAM."""
    digest = hashlib.sha256()
    with Path(path).open('rb') as source:
        for block in iter(lambda: source.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def _json_default(value: Any) -> Any:
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, np.generic):
        return value.item()
    raise TypeError(f'Cannot JSON-encode {type(value).__name__}.')


def _installed_distribution_version(distribution_name: str) -> str | None:
    """Return an installed package version without making a run fail on metadata."""
    try:
        return distribution_version(distribution_name)
    except PackageNotFoundError:
        return None


def runtime_environment() -> dict[str, Any]:
    """Record the resolved Colab software and GPU environment for reproducibility."""
    gpu_name = None
    if torch.cuda.is_available():
        gpu_name = torch.cuda.get_device_name(0)
    package_names = {
        'matplotlib': 'matplotlib',
        'numpy': 'numpy',
        'pandas': 'pandas',
        'rdkit': 'rdkit',
        'scikit_learn': 'scikit-learn',
        'torch': 'torch',
        'torch_geometric': 'torch-geometric',
    }
    return {
        'python_version': platform.python_version(),
        'python_implementation': platform.python_implementation(),
        'platform': platform.platform(),
        'cuda_available': torch.cuda.is_available(),
        'cuda_version': torch.version.cuda,
        'gpu_name': gpu_name,
        'package_versions': {
            name: _installed_distribution_version(distribution)
            for name, distribution in package_names.items()
        },
    }


def repository_git_commit() -> str | None:
    """Return the source revision when training from a Git checkout."""
    try:
        completed = subprocess.run(
            ['git', 'rev-parse', 'HEAD'],
            cwd=PROJECT_ROOT,
            check=True,
            capture_output=True,
            text=True,
        )
    except (OSError, subprocess.CalledProcessError):
        return None
    return completed.stdout.strip() or None


def write_json(path: str | Path, payload: dict[str, Any]) -> None:
    """Write an auditable JSON artifact with a stable UTF-8 encoding."""
    artifact_path = Path(path)
    artifact_path.parent.mkdir(parents=True, exist_ok=True)
    with artifact_path.open('w', encoding='utf-8') as destination:
        json.dump(payload, destination, indent=2, sort_keys=True, default=_json_default)


def safe_checkpoint_save(state_dict_bundle: dict[str, Any], path: str | Path) -> str:
    """Atomically save, safe-reload, and hash a checkpoint before replacing it."""
    final_path = Path(path)
    final_path.parent.mkdir(parents=True, exist_ok=True)
    descriptor, temporary_name = tempfile.mkstemp(
        prefix=f'.{final_path.name}.', suffix='.tmp', dir=final_path.parent
    )
    os.close(descriptor)
    temporary_path = Path(temporary_name)
    try:
        torch.save(state_dict_bundle, temporary_path)
        loaded = torch.load(temporary_path, map_location='cpu', weights_only=False)
        if not isinstance(loaded, dict):
            raise ValueError('Checkpoint validation failed: expected a dictionary.')
        if set(loaded) != set(state_dict_bundle):
            raise ValueError('Checkpoint validation failed: keys changed after saving.')
        checkpoint_hash = get_file_hash(temporary_path)
        os.replace(temporary_path, final_path)
        return checkpoint_hash
    finally:
        if temporary_path.exists():
            temporary_path.unlink()


# Backward-compatible name used by earlier Colab cells and documentation.
save_checkpoint_safe = safe_checkpoint_save


def persist_finalized_checkpoint(
    checkpoint: dict[str, Any],
    checkpoint_path: str | Path,
    *,
    evaluation_only: bool,
) -> str:
    """Persist training finalization, but keep checkpoint-only evaluation read-only.

    An evaluation run may regenerate reports from the same audited inputs, but
    it must not silently change the model bundle, its artifact pointers, or
    its SHA-256 identity. Normal training finalization remains atomic.
    """
    path = Path(checkpoint_path)
    if evaluation_only:
        if not path.is_file():
            raise FileNotFoundError(f'Checkpoint does not exist: {path}.')
        return get_file_hash(path)
    return safe_checkpoint_save(checkpoint, path)


def build_run_manifest() -> dict[str, Any]:
    """Capture immutable inputs before any model fitting begins."""
    required_paths = {
        'training_source': Path(__file__),
    }
    if TWOSIDES_PARQUET.is_file() and TWOSIDES_DRUGS.is_file():
        required_paths['twosides_clean_parquet'] = TWOSIDES_PARQUET
        required_paths['twosides_drug_catalogue'] = TWOSIDES_DRUGS
    else:
        required_paths['legacy_twosides_edges'] = TWOSIDES_EDGES
    if USE_TOXICITY_PAIR_FEATURES or TOXICITY_LOSS_WEIGHT > 0.0:
        required_paths['toxicity_bridge'] = TOXICITY_BRIDGE
    if USE_SEVEN_SOURCE_FEATURES:
        required_paths['seven_source_feature_matrix'] = SOURCE_FEATURE_MATRIX
        required_paths['seven_source_bundle_manifest'] = SOURCE_BUNDLE_MANIFEST
        required_paths['ddinter_match_audit'] = DDINTER_MATCH_AUDIT
        required_paths['ddinter_prepared_pairs'] = SOURCE_BUNDLE / 'ddinter_pairs.csv'
        if PRETRAINED_ENCODER_PATH is None:
            raise ValueError(
                'The seven-source architecture requires a ChEMBL-pretrained encoder. '
                'Set AUDITDDI_PRETRAINED_ENCODER_PATH to its checkpoint.'
            )
        bundle = json.loads(SOURCE_BUNDLE_MANIFEST.read_text(encoding='utf-8'))
        if bundle.get('source_roles', {}).get('openFDA', {}).get('status') != 'parsed':
            raise ValueError(
                'The seven-source feature bundle has no parsed openFDA features. '
                'Rebuild it with --parse-openfda before training.'
            )
        openfda_info = bundle.get('source_roles', {}).get('openFDA', {})
        if int(openfda_info.get('archives', 0)) == 0 or int(openfda_info.get('drug_feature_rows', 0)) == 0:
            raise ValueError('The source bundle has no attributed openFDA drug-label features.')
        if bundle.get('source_roles', {}).get('ChEMBL', {}).get('status') != 'available':
            raise ValueError('The source bundle does not list the expected ChEMBL chemreps corpus.')
        if int(bundle.get('counts', {}).get('pharmgkb_matched_drug_gene_rows', 0)) == 0:
            raise ValueError('The seven-source feature bundle contains no matched PharmGKB gene rows.')
        if int(bundle.get('counts', {}).get('faers_matched_drugs', 0)) == 0:
            raise ValueError('The seven-source feature bundle contains no matched FAERS drugs.')
        if int(bundle.get('counts', {}).get('ddinter_unique_pairs', 0)) == 0:
            raise ValueError('The seven-source feature bundle contains no mapped DDInter pairs.')
    if USE_SEVEN_BRANCH_MODEL:
        required_paths['seven_branch_feature_bundle'] = SEVEN_BRANCH_FEATURE_BUNDLE
        required_paths['seven_branch_feature_manifest'] = SEVEN_BRANCH_FEATURE_BUNDLE.with_suffix('.manifest.json')
        if PRETRAINED_ENCODER_PATH is None:
            raise ValueError(
                'The seven-branch architecture requires the audited ChEMBL-pretrained '
                'graph encoder. Set AUDITDDI_PRETRAINED_ENCODER_PATH.'
            )
        branch_manifest = json.loads(
            SEVEN_BRANCH_FEATURE_BUNDLE.with_suffix('.manifest.json').read_text(encoding='utf-8')
        )
        if branch_manifest.get('schema') != 'auditddi_seven_branch_feature_bundle_v1':
            raise ValueError('Seven-branch feature manifest schema is not supported.')
        if (
            branch_manifest.get('bundle_sha256')
            and get_file_hash(SEVEN_BRANCH_FEATURE_BUNDLE) != branch_manifest['bundle_sha256']
        ):
            raise ValueError('Seven-branch feature bundle hash does not match its manifest.')
        declared_branches = branch_manifest.get('branches', {})
        missing_branches = set(SEVEN_BRANCH_NAMES).difference(declared_branches)
        if missing_branches:
            raise ValueError(f'Seven-branch manifest is missing branches: {sorted(missing_branches)}.')
        for branch in SEVEN_BRANCH_NAMES:
            if int(declared_branches[branch].get('available_drugs', 0)) <= 0:
                raise ValueError(f'Seven-branch manifest reports no observed data for {branch}.')
        source_provenance = branch_manifest.get('source_provenance', {})
        for branch in SEVEN_BRANCH_NAMES:
            details = source_provenance.get(branch, {})
            for field in ('dataset', 'release', 'feature_definition', 'drug_identity_mapping'):
                if not str(details.get(field, '')).strip():
                    raise ValueError(
                        f'Seven-branch provenance for {branch} must declare {field}.'
                    )
        adverse_event_provenance = source_provenance.get('adverse_event', {})
        if adverse_event_provenance.get('pairwise_ddi_signals_excluded') is not True:
            raise ValueError(
                'Adverse-event features require provenance confirming pairwise DDI '
                'signals were excluded.'
            )
        if not str(adverse_event_provenance.get('cutoff_date', '')).strip():
            raise ValueError('Adverse-event feature provenance must declare cutoff_date.')
        for branch, field in (
            ('protein_target', 'activity_encoding'),
            ('pdb_structure', 'structure_to_drug_mapping'),
            ('gene_expression', 'cell_or_tissue_context'),
            ('gene_expression', 'perturbation_type'),
            ('gene_expression', 'aggregation_rule'),
        ):
            if not str(source_provenance.get(branch, {}).get(field, '')).strip():
                raise ValueError(f'Seven-branch provenance for {branch} must declare {field}.')
        required_paths['ddinter_match_audit'] = DDINTER_MATCH_AUDIT
        required_paths['ddinter_prepared_pairs'] = SOURCE_BUNDLE / 'ddinter_pairs.csv'
    if PRETRAINED_ENCODER_PATH is not None:
        required_paths['pretrained_encoder'] = PRETRAINED_ENCODER_PATH
    if USE_MOTIF_FEATURES:
        required_paths['motif_definitions_source'] = (
            PROJECT_ROOT / 'src' / 'data_prep' / 'molecular_motifs.py'
        )
    missing = [name for name, path in required_paths.items() if not path.exists()]
    if missing:
        raise FileNotFoundError(f'Missing required Colab inputs: {missing}.')
    return {
        'run_id': RUN_ID,
        'created_at_utc': datetime.now(timezone.utc).isoformat(),
        'device': str(DEVICE),
        'input_data_base': str(DRIVE_BASE),
        'results_base': str(RESULTS_BASE),
        'source_usage': (
            {
                'supervised_pair_labels': ['TWOSIDES'],
                'drug_identity_and_structure': ['PubChem'],
                'graph_encoder_pretraining': ['ChEMBL'],
                'seven_branch_feature_provenance': {
                    branch: declared_branches[branch] for branch in SEVEN_BRANCH_NAMES
                },
                'known_positive_pair_exclusion_from_negative_sampling': ['DDInter'],
                'negative_label_interpretation': 'unreported evidence; not known safe',
                'all_seven_model_branches_required': True,
            }
            if USE_SEVEN_BRANCH_MODEL
            else (
            {
                'supervised_pair_labels': ['TWOSIDES'],
                'molecular_structures': ['PubChem'],
                'molecular_encoder_pretraining': ['ChEMBL'],
                'drug_level_input_features': ['PharmGKB', 'openFDA'],
                'pharmacovigilance_audit_only': ['FAERS'],
                'faers_feature_policy': 'report counts excluded pending temporal-overlap and reporting-bias evaluation',
                'known_positive_pair_exclusion_from_negative_sampling': ['DDInter'],
                'ddinter_pairs_are_training_labels': False,
                'negative_label_interpretation': 'unreported evidence; not known safe',
            }
            if USE_SEVEN_SOURCE_FEATURES
            else {
                'supervised_pair_labels': ['TWOSIDES'],
                'molecular_structures': ['PubChem'],
                'not_consumed_by_this_trainer': [
                    'ChEMBL', 'openFDA', 'FAERS', 'DDInter', 'PharmGKB'
                ],
                'warning': 'This run is a TWOSIDES+PubChem molecular baseline, not a seven-source fused model.',
            }
            )
        ),
        'repository_git_commit': repository_git_commit(),
        'runtime_environment': runtime_environment(),
        'random_seed': MODEL_SEED,
        'model_seed': MODEL_SEED,
        'split_seed': SPLIT_SEED,
        'configuration': {
            'data_cap': DATA_CAP,
            'model_seed': MODEL_SEED,
            'split_seed': SPLIT_SEED,
            'epochs': EPOCHS,
            'resume_after_epoch': RESUME_AFTER_EPOCH if RESUME_CHECKPOINT_PATH else None,
            'hidden_channels': HIDDEN_CHANNELS,
            'batch_size': BATCH_SIZE,
            'early_stopping_patience': EARLY_STOPPING_PATIENCE,
            'early_stopping_min_epochs': EARLY_STOPPING_MIN_EPOCHS,
            'model_selection_validation_fraction': MODEL_SELECTION_VALIDATION_FRACTION,
            'validation_role_protocol': (
                'stratified_disjoint_model_selection_then_posthoc_three_way_v1'
            ),
            'use_chemberta': USE_CHEMBERTA,
            'model_architecture': MODEL_ARCHITECTURE,
            'feature_schema': FEATURE_SCHEMA,
            'use_motif_features': USE_MOTIF_FEATURES,
            'use_fingerprint_features': USE_FINGERPRINT_FEATURES,
            'neighbor_memory_training_query_policy': (
                'exclude_exact_query_pair_from_interaction_matrix_v1'
                if USE_NEIGHBOR_MEMORY else None
            ),
            'use_cross_drug_attention': USE_CROSS_DRUG_ATTENTION,
            'cross_drug_attention_type': (
                'pair_isolated_atom_attention_v1'
                if USE_CROSS_DRUG_ATTENTION else None
            ),
            'motif_feature_schema': (
                MOTIF_SCHEMA_SMARTS_COUNTS_V1 if USE_MOTIF_FEATURES else None
            ),
            'motif_feature_dim': MOTIF_FEATURE_DIM if USE_MOTIF_FEATURES else None,
            'motif_hidden_channels': MOTIF_HIDDEN_CHANNELS if USE_MOTIF_FEATURES else None,
            'use_toxicity_pair_features': USE_TOXICITY_PAIR_FEATURES,
            'use_seven_source_drug_features': USE_SEVEN_SOURCE_FEATURES,
            'use_seven_branch_model': USE_SEVEN_BRANCH_MODEL,
            'seven_branch_feature_bundle_path': str(SEVEN_BRANCH_FEATURE_BUNDLE) if USE_SEVEN_BRANCH_MODEL else None,
            'seven_branch_feature_bundle_sha256': (
                get_file_hash(SEVEN_BRANCH_FEATURE_BUNDLE) if USE_SEVEN_BRANCH_MODEL else None
            ),
            'seven_source_feature_dimension': SEVEN_SOURCE_FEATURE_DIM if USE_SEVEN_SOURCE_FEATURES else None,
            'toxicity_loss_weight': TOXICITY_LOSS_WEIGHT,
            'edge_feature_dim': (
                NUM_BOND_FEATURES
                if USES_EDGE_FEATURES else None
            ),
            'pretrained_encoder_checkpoint_path': (
                str(PRETRAINED_ENCODER_PATH)
                if PRETRAINED_ENCODER_PATH is not None else None
            ),
            'negative_label_meaning': NEGATIVE_LABEL_MEANING,
            'negative_sampling_protocol': NEGATIVE_SAMPLING_PROTOCOL,
            'toxicity_conflict_policy': 'exclude_conflicting_structures',
            'evaluation_protocol': EVALUATION_PROTOCOL,
            'test_set_bootstrap': {
                'method': 'stratified_nonparametric_bootstrap',
                'resamples': BOOTSTRAP_RESAMPLES,
                'seed': SPLIT_SEED,
                'metrics': [
                    'auroc', 'average_precision', 'f1', 'mcc',
                    'balanced_accuracy', 'brier_score_calibrated',
                ],
            },
            'error_analysis': {
                'method': 'confidence_ranked_threshold_errors',
                'maximum_rows_per_error_type': ERROR_ANALYSIS_MAX_ROWS,
            },
            'candidate_explanations': {
                'enabled': RUN_CANDIDATE_EXPLANATIONS,
                'method': EXPLANATION_METHOD,
                'samples_per_split': EXPLANATION_SAMPLES_PER_SPLIT,
                'top_k': EXPLANATION_TOP_K,
                'uses_raw_model_probabilities': True,
            },
            'uncertainty': {
                'conformal_method': 'split_conformal_binary_v1',
                'conformal_alpha': CONFORMAL_ALPHA,
                'applicability_domain_method': 'nearest_train_ecfp_tanimoto_v1',
                'applicability_domain_minimum_similarity': (
                    APPLICABILITY_DOMAIN_MINIMUM_SIMILARITY
                ),
            },
        },
        'input_sha256': {name: get_file_hash(path) for name, path in required_paths.items()},
    }


def save_split_manifests(
    splits: dict[str, pd.DataFrame], artifact_dir: Path
) -> dict[str, dict[str, Any]]:
    """Save exact split tables and their hashes before training."""
    split_dir = artifact_dir / 'splits'
    split_dir.mkdir(parents=True, exist_ok=True)
    manifest: dict[str, dict[str, Any]] = {}
    for name, frame in splits.items():
        split_path = split_dir / f'{name}.csv'
        frame.to_csv(split_path, index=False)
        label_counts = frame['label'].value_counts().to_dict() if 'label' in frame else {}
        manifest[name] = {
            'path': str(split_path),
            'sha256': get_file_hash(split_path),
            'rows': len(frame),
            'label_counts': {str(label): int(count) for label, count in label_counts.items()},
        }
    write_json(split_dir / 'split_manifest.json', manifest)
    return manifest


def split_manifest_fingerprint(split_manifest: dict[str, dict[str, Any]]) -> str:
    """Hash stable split evidence without including run-specific file paths."""
    evidence = {
        name: {
            'sha256': details.get('sha256'),
            'rows': details.get('rows'),
            'label_counts': details.get('label_counts'),
        }
        for name, details in sorted(split_manifest.items())
    }
    if not evidence or any(not details['sha256'] for details in evidence.values()):
        raise ValueError('Split manifest must contain a SHA-256 hash for every split.')
    encoded = json.dumps(evidence, sort_keys=True, separators=(',', ':')).encode('utf-8')
    return hashlib.sha256(encoded).hexdigest()


def external_overlap_training_split(
    split_manifest: dict[str, dict[str, Any]], train_split_key: str
) -> dict[str, Any]:
    """Return the verified training split needed to screen external datasets.

    External evaluation must reject an exact molecular pair that was used for
    fitting.  Store the concrete split artifact and hash with new checkpoints
    so the external evaluator can prove that screen instead of relying on a
    user assertion.
    """
    details = split_manifest.get(train_split_key)
    if not isinstance(details, dict):
        raise ValueError(
            f"Training split {train_split_key!r} is absent from the split manifest."
        )
    required = ('path', 'sha256', 'rows')
    missing = [key for key in required if details.get(key) is None]
    if missing:
        raise ValueError(
            'Training split artifact is incomplete for external-overlap screening; '
            f'missing: {missing}.'
        )
    return {
        'split_name': train_split_key,
        'path': str(details['path']),
        'sha256': str(details['sha256']),
        'rows': int(details['rows']),
    }


def external_overlap_development_splits(
    split_manifest: dict[str, dict[str, Any]]
) -> dict[str, dict[str, Any]]:
    """Record every development split for strict external-overlap screening."""
    if not split_manifest:
        raise ValueError('Split manifest is empty; external-overlap screening is unavailable.')
    return {
        split_name: external_overlap_training_split(split_manifest, split_name)
        for split_name in sorted(split_manifest)
    }


def evaluation_checkpoint_provenance(
    manifest: dict[str, Any], split_manifest: dict[str, dict[str, Any]]
) -> dict[str, Any]:
    """Capture the exact run inputs that checkpoint-only evaluation must match."""
    return {
        'input_sha256': manifest['input_sha256'],
        'split_manifest_fingerprint': split_manifest_fingerprint(split_manifest),
        'model_architecture': MODEL_ARCHITECTURE,
        'feature_schema': FEATURE_SCHEMA,
        'in_channels': INPUT_FEATURE_DIM,
        'hidden_channels': HIDDEN_CHANNELS,
        'data_cap': DATA_CAP,
        'model_seed': MODEL_SEED,
        'split_seed': SPLIT_SEED,
        'negative_sampling_strategy': NEGATIVE_SAMPLING_STRATEGY,
        'negative_sampling_protocol': NEGATIVE_SAMPLING_PROTOCOL,
        'use_toxicity_pair_features': USE_TOXICITY_PAIR_FEATURES,
        'toxicity_loss_weight': TOXICITY_LOSS_WEIGHT,
        'use_pdb_encoder': USE_PDB_ENCODER,
        'use_clinical_toxicity': USE_CLINICAL_TOXICITY,
        'use_gene_encoder': USE_SEVEN_SOURCE_FEATURES,
        'gene_feature_dim': SEVEN_SOURCE_FEATURE_DIM if USE_SEVEN_SOURCE_FEATURES else 50,
        'model_selection_validation_fraction': MODEL_SELECTION_VALIDATION_FRACTION,
    }


def load_warm_start_checkpoint(
    path: str | Path,
    model: torch.nn.Module,
    manifest: dict[str, Any],
    split_manifest: dict[str, dict[str, Any]],
    resume_after_epoch: int,
) -> tuple[dict[str, Any], dict[str, Any]]:
    """Load best model weights for a guarded continuation after an interrupted run.

    This is deliberately a warm start: the historical trainer checkpoints do
    not contain Adam or scheduler state. The code hash is allowed to differ
    because this resume support itself changes the trainer, but all data and
    split hashes must still match.
    """
    source = Path(path)
    if not source.is_file():
        raise FileNotFoundError(f'Warm-start checkpoint does not exist: {source}.')
    checkpoint = torch.load(source, map_location='cpu', weights_only=False)
    if not isinstance(checkpoint, dict):
        raise TypeError('Warm-start checkpoint must be a metadata dictionary.')
    state_dict = checkpoint.get('model_state_dict')
    provenance = checkpoint.get('evaluation_provenance')
    if not isinstance(state_dict, dict) or not isinstance(provenance, dict):
        raise ValueError('Warm-start checkpoint is missing model weights or provenance.')

    expected = evaluation_checkpoint_provenance(manifest, split_manifest)
    old_hashes = provenance.get('input_sha256')
    new_hashes = expected.get('input_sha256')
    if not isinstance(old_hashes, dict) or not isinstance(new_hashes, dict):
        raise ValueError('Warm-start checkpoint has no auditable input hashes.')
    # The trainer file necessarily changed to add this warm-start path. Every
    # data/pretraining input hash must remain identical.
    old_data_hashes = {key: value for key, value in old_hashes.items() if key != 'training_source'}
    new_data_hashes = {key: value for key, value in new_hashes.items() if key != 'training_source'}
    if old_data_hashes != new_data_hashes:
        raise ValueError(
            'Warm-start checkpoint data inputs differ from the current run: '
            f'{old_data_hashes} != {new_data_hashes}.'
        )
    # A small set of architecture fields was added to checkpoint provenance
    # after earlier seed runs had already been produced. If such a field is
    # absent or null, the checkpoint can still be resumed only when its
    # architecture version matches and the complete state dict passes strict
    # loading below. Explicitly recorded conflicts remain fatal.
    state_dict_verified_legacy_fields = {
        'use_pdb_encoder',
        'use_clinical_toxicity',
        'use_gene_encoder',
        'gene_feature_dim',
    }
    unknown_legacy_fields = sorted(
        key for key in state_dict_verified_legacy_fields
        if key in expected and (key not in provenance or provenance[key] is None)
    )
    mismatches = {
        key: {'checkpoint': provenance.get(key), 'current_run': value}
        for key, value in expected.items()
        if key not in {'input_sha256'}
        and key in provenance
        and not (key in state_dict_verified_legacy_fields and provenance[key] is None)
        and provenance[key] != value
    }
    unexpected_missing = {
        key: value
        for key, value in expected.items()
        if key not in {'input_sha256'}
        and key not in provenance
        and key not in state_dict_verified_legacy_fields
    }
    mismatches.update({
        key: {'checkpoint': '<missing>', 'current_run': value}
        for key, value in unexpected_missing.items()
    })
    if mismatches:
        raise ValueError(f'Warm-start checkpoint configuration differs: {mismatches}.')
    checkpoint_epoch = int(checkpoint.get('epoch', 0))
    if checkpoint_epoch <= 0 or checkpoint_epoch > resume_after_epoch:
        raise ValueError(
            'Warm-start checkpoint epoch must be positive and no later than '
            f'{resume_after_epoch}; got {checkpoint_epoch}.'
        )
    if checkpoint.get('architecture_version') != MODEL_ARCHITECTURE:
        raise ValueError('Warm-start checkpoint architecture does not match this run.')
    model.load_state_dict(state_dict, strict=True)
    if unknown_legacy_fields:
        print(
            'Warm-start compatibility: older checkpoint has absent/null provenance '
            f'fields {unknown_legacy_fields}; architecture and strict parameter '
            'loading matched.'
        )
    info = {
        'mode': 'best_checkpoint_weights_warm_start',
        'checkpoint_path': str(source),
        'checkpoint_sha256': get_file_hash(source),
        'checkpoint_epoch': checkpoint_epoch,
        'checkpoint_validation_auroc': float(checkpoint.get('auroc', float('nan'))),
        'resume_after_epoch': resume_after_epoch,
        'optimizer_state_restored': False,
        'scheduler_state_restored': False,
        'trainer_source_hash_may_differ': True,
    }
    return checkpoint, info


def validate_checkpoint_for_evaluation(
    checkpoint: dict[str, Any],
    manifest: dict[str, Any],
    split_manifest: dict[str, dict[str, Any]],
) -> dict[str, Any]:
    """Refuse checkpoint-only evaluation when data, splits, or model differ.

    Recreating a split from whatever happens to be in Drive can silently turn
    a valid checkpoint into an invalid evaluation.  Checkpoints created before
    this provenance contract are intentionally rejected rather than guessed.
    """
    if not isinstance(checkpoint, dict):
        raise ValueError('Checkpoint must be a metadata dictionary.')
    expected = evaluation_checkpoint_provenance(manifest, split_manifest)
    provenance = checkpoint.get('evaluation_provenance')
    if not isinstance(provenance, dict):
        raise ValueError(
            'Checkpoint has no evaluation provenance. Re-evaluate only a checkpoint '
            'created by the current audited training pipeline.'
        )
    missing = sorted(set(expected).difference(provenance))
    if missing:
        raise ValueError(
            'Checkpoint evaluation provenance is incomplete; missing: '
            f'{missing}.'
        )
    mismatches = {
        key: {'checkpoint': provenance[key], 'current_run': expected[key]}
        for key in expected
        if provenance[key] != expected[key]
    }
    if mismatches:
        raise ValueError(
            'Checkpoint does not match the current evaluation inputs, split, or model '
            f'configuration: {mismatches}.'
        )

    # Provenance is an audit record, not a substitute for validating the
    # checkpoint that will actually be loaded.  Reject a malformed or manually
    # edited bundle whose top-level model metadata disagrees with that record
    # before attempting to restore its state dictionary.
    metadata_contract = {
        'architecture_version': 'model_architecture',
        'feature_schema': 'feature_schema',
        'in_channels': 'in_channels',
        'hidden_channels': 'hidden_channels',
        'data_cap': 'data_cap',
        'model_seed': 'model_seed',
        'split_seed': 'split_seed',
        'use_toxicity_pair_features': 'use_toxicity_pair_features',
        'toxicity_loss_weight': 'toxicity_loss_weight',
        'use_pdb_encoder': 'use_pdb_encoder',
        'use_clinical_toxicity': 'use_clinical_toxicity',
        'use_gene_encoder': 'use_gene_encoder',
        'gene_feature_dim': 'gene_feature_dim',
    }
    missing_metadata = [key for key in metadata_contract if key not in checkpoint]
    if missing_metadata:
        raise ValueError(
            'Checkpoint metadata is incomplete for provenance-checked evaluation; '
            f'missing: {missing_metadata}.'
        )
    metadata_mismatches = {
        checkpoint_key: {
            'checkpoint': checkpoint[checkpoint_key],
            'evaluation_provenance': provenance[provenance_key],
        }
        for checkpoint_key, provenance_key in metadata_contract.items()
        if checkpoint[checkpoint_key] != provenance[provenance_key]
    }
    if metadata_mismatches:
        raise ValueError(
            'Checkpoint metadata disagrees with its evaluation provenance: '
            f'{metadata_mismatches}.'
        )
    return expected


def load_checkpoint_training_history(checkpoint: dict[str, Any]) -> dict[str, list[float]]:
    """Load verified real training history for checkpoint-only evaluation."""
    metadata = checkpoint.get('training_history')
    if not isinstance(metadata, dict) or not metadata.get('path') or not metadata.get('sha256'):
        raise ValueError(
            'Checkpoint has no verified training-history artifact. Refusing to create '
            'a synthetic convergence history for checkpoint-only evaluation.'
        )
    path = Path(metadata['path'])
    if not path.is_file():
        raise FileNotFoundError(
            f'Checkpoint training-history artifact is unavailable: {path}. '
            'Restore the original artifact directory before evaluating this checkpoint.'
        )
    if get_file_hash(path) != metadata['sha256']:
        raise ValueError('Checkpoint training-history hash does not match its artifact.')
    return load_training_history_file(path)


def load_training_history_file(path: str | Path) -> dict[str, list[float]]:
    """Read a real saved epoch history, retaining missing validation-loss gaps."""
    table = pd.read_csv(path)
    required_columns = (
        'epoch', 'loss', 'auroc', 'average_precision', 'f1', 'mcc',
        'balanced_accuracy', 'threshold', 'learning_rate',
    )
    missing = [column for column in required_columns if column not in table]
    if missing or table.empty:
        raise ValueError(
            'Checkpoint training-history artifact is incomplete; missing columns: '
            f'{missing}.'
        )
    history = {
        column: pd.to_numeric(table[column], errors='raise').astype(float).tolist()
        for column in required_columns
    }
    if 'val_loss' in table:
        history['val_loss'] = pd.to_numeric(
            table['val_loss'], errors='coerce'
        ).astype(float).tolist()
    else:
        # Older runs did not log validation loss. Preserve their training-loss
        # history, but leave explicit gaps instead of fabricating values.
        history['val_loss'] = [float('nan')] * len(table)
    if any(len(values) != len(table) for values in history.values()):
        raise ValueError('Saved training history columns have inconsistent lengths.')
    return history


def save_training_history(history: dict[str, list[float]], artifact_dir: Path) -> dict[str, Any]:
    """Save the numeric source data behind the convergence figure."""
    lengths = {len(values) for values in history.values()}
    if len(lengths) != 1:
        raise ValueError('Training history fields must have equal lengths.')
    history_path = artifact_dir / 'training_history.csv'
    pd.DataFrame(history).to_csv(history_path, index=False)
    return {
        'path': str(history_path),
        'sha256': get_file_hash(history_path),
        'epoch_count': next(iter(lengths), 0),
    }


def save_evaluation_metrics(
    results: dict[str, dict[str, Any]],
    artifact_dir: Path,
    *,
    negative_label_meaning: str = NEGATIVE_LABEL_MEANING,
) -> dict[str, Any]:
    """Write the compact, paper-ready metrics table promised by each run.

    ``results_summary.json`` intentionally preserves rich nested diagnostics.
    This CSV carries the complementary per-split headline metrics in a stable,
    tabular form for inspection and controlled experiment aggregation.
    """
    table = evaluation_metric_table(results, negative_label_meaning)
    path = Path(artifact_dir) / 'evaluation_metrics.csv'
    table.to_csv(path, index=False)
    return {
        'path': str(path),
        'sha256': get_file_hash(path),
        'rows': len(table),
        'columns': list(table.columns),
        'negative_label_meaning': negative_label_meaning,
    }


def publish_latest_results(
    run_artifacts_dir: Path,
    latest_results_dir: Path = LATEST_RESULTS_DIR,
) -> Path:
    """Refresh one easy-to-find latest-results folder after a completed run.

    Timestamped run folders remain immutable evidence. This lightweight mirror
    deliberately overwrites only the current figures and summary files, so a
    Colab user can always open one stable folder for the latest output.
    """
    run_dir = Path(run_artifacts_dir)
    latest_dir = Path(latest_results_dir)
    required_files = [
        Path('run_manifest_initial.json'),
        Path('run_manifest.json'),
        Path('results_summary.json'),
        Path('evaluation_metrics.csv'),
        Path('training_history.csv'),
        Path('audits/toxicity_bridge_summary.json'),
        Path('audits/invalid_smiles_exclusions.csv'),
        Path('audits/input_quality_summary.json'),
        Path('audits/dataset_summary.json'),
        Path('audits/counterion_curation_candidates.csv'),
    ]
    # DDI-only runs intentionally disable this auxiliary source and therefore
    # have no conflict table to publish.
    optional_conflicts = Path('audits/toxicity_bridge_conflicts.csv')
    if (run_dir / optional_conflicts).is_file():
        required_files.append(optional_conflicts)
    missing = [str(relative) for relative in required_files if not (run_dir / relative).is_file()]
    if missing:
        raise FileNotFoundError(
            f'Cannot publish incomplete run artifacts; missing: {missing}.'
        )

    latest_dir.mkdir(parents=True, exist_ok=True)
    copied_files: list[str] = []
    for relative in required_files:
        source = run_dir / relative
        destination = latest_dir / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, destination)
        copied_files.append(str(relative))

    for artifact_subdirectory in (
        'figures', 'predictions', 'explanations', 'uncertainty', 'error_analysis', 'splits'
    ):
        artifact_dir = run_dir / artifact_subdirectory
        if not artifact_dir.exists():
            continue
        for source in sorted(artifact_dir.rglob('*')):
            if source.is_file():
                relative = source.relative_to(run_dir)
                destination = latest_dir / relative
                destination.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(source, destination)
                copied_files.append(str(relative))

    write_json(latest_dir / 'latest_run.json', {
        'source_run_directory': str(run_dir),
        'source_run_id': run_dir.name,
        'refreshed_at_utc': datetime.now(timezone.utc).isoformat(),
        'mirrored_files': copied_files,
    })
    return latest_dir


def graph_compatibility_reason(smiles: Any) -> str | None:
    """Use the shared molecular parser to identify unusable training inputs."""
    return source_graph_compatibility_reason(smiles)


def filter_graph_compatible_pairs(
    dataframe: pd.DataFrame,
    source_col: str = 'source',
    target_col: str = 'target',
) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Exclude graph-incompatible pairs before splitting and retain an audit table."""
    missing = {source_col, target_col}.difference(dataframe.columns)
    if missing:
        raise ValueError(f'Pair data is missing required columns: {sorted(missing)}.')

    keep_rows: list[bool] = []
    exclusions: list[dict[str, Any]] = []
    audit_columns = ['dataset_row_index', *dataframe.columns, 'source_graph_status', 'target_graph_status']
    for row_index, row in dataframe.iterrows():
        source_reason = graph_compatibility_reason(row[source_col])
        target_reason = graph_compatibility_reason(row[target_col])
        source_status = source_reason or 'graph_compatible'
        target_status = target_reason or 'graph_compatible'
        keep_row = source_reason is None and target_reason is None
        keep_rows.append(keep_row)
        if not keep_row:
            exclusions.append({
                'dataset_row_index': str(row_index),
                **row.to_dict(),
                'source_graph_status': source_status,
                'target_graph_status': target_status,
            })

    clean = dataframe.loc[keep_rows].copy().reset_index(drop=True)
    return clean, pd.DataFrame(exclusions, columns=audit_columns)


def save_counterion_curation_candidates(exclusions: pd.DataFrame, audit_dir: Path) -> dict[str, Any]:
    """Create a review queue; never guess a parent drug for an isolated ion."""
    counterion_columns = ['source_graph_status', 'target_graph_status']
    occurrences: dict[str, dict[str, Any]] = {}
    for side in ('source', 'target'):
        status_column = f'{side}_graph_status'
        if status_column not in exclusions:
            continue
        subset = exclusions[
            exclusions[status_column] == 'counterion_or_inorganic_only_structure'
        ]
        for structure, count in subset[side].value_counts().items():
            candidate = occurrences.setdefault(str(structure), {
                'raw_structure': structure,
                'occurrence_count': 0,
                'observed_as': set(),
                'audit_reason': 'counterion_or_inorganic_only_structure',
                'recommended_action': 'exclude_until_authoritative_parent_drug_mapping_is_reviewed',
                'curation_decision': 'pending_manual_review',
                'authoritative_source': '',
                'approved_parent_smiles': '',
                'review_notes': '',
            })
            candidate['occurrence_count'] += count
            candidate['observed_as'].add(side)
    candidates = []
    for candidate in occurrences.values():
        candidate['observed_as'] = '|'.join(sorted(candidate['observed_as']))
        candidates.append(candidate)
    candidate_columns = [
        'raw_structure',
        'occurrence_count',
        'observed_as',
        'audit_reason',
        'recommended_action',
        'curation_decision',
        'authoritative_source',
        'approved_parent_smiles',
        'review_notes',
    ]
    candidates_path = audit_dir / 'counterion_curation_candidates.csv'
    pd.DataFrame(candidates, columns=candidate_columns).to_csv(candidates_path, index=False)
    return {
        'counterion_only_pair_exclusions': (
            (
                exclusions[counterion_columns]
                == 'counterion_or_inorganic_only_structure'
            ).any(axis=1).sum()
        ) if not exclusions.empty else 0,
        'unique_counterion_or_inorganic_structures': len(candidates),
        'curation_candidates_path': str(candidates_path),
        'curation_candidates_sha256': get_file_hash(candidates_path),
        'automatic_parent_mapping_applied': False,
    }


def load_toxicity_lookup(audit_dir: Path) -> tuple[dict[str, float], dict[str, Any]]:
    """Save toxicity conflicts to the current run and return clean labels only."""
    if not TOXICITY_BRIDGE.is_file() and not (
        USE_TOXICITY_PAIR_FEATURES or TOXICITY_LOSS_WEIGHT > 0.0
    ):
        summary = {
            'source_rows': 0,
            'rows_with_canonical_smiles': 0,
            'unique_canonical_structures': 0,
            'resolved_unique_canonical_structures': 0,
            'excluded_conflicting_structures': 0,
            'conflict_policy': 'not_enabled',
            'source_bridge_sha256': None,
            'conflict_report_path': None,
        }
        write_json(audit_dir / 'toxicity_bridge_summary.json', summary)
        print('Toxicity bridge: disabled for this DDI-only run.')
        return {}, summary
    bridge = pd.read_csv(TOXICITY_BRIDGE)
    resolved, summary, conflicts = resolve_toxicity_bridge(bridge)
    audit_dir.mkdir(parents=True, exist_ok=True)
    conflicts.to_csv(audit_dir / 'toxicity_bridge_conflicts.csv', index=False)
    summary = {
        **summary,
        'conflict_policy': 'exclude_conflicting_structures',
        'source_bridge_sha256': get_file_hash(TOXICITY_BRIDGE),
        'conflict_report_path': str(audit_dir / 'toxicity_bridge_conflicts.csv'),
    }
    write_json(audit_dir / 'toxicity_bridge_summary.json', summary)
    print(
        'Toxicity bridge: '
        f"{summary['source_rows']} source rows; "
        f"{summary['resolved_unique_canonical_structures']} clean structures; "
        f"{summary['excluded_conflicting_structures']} conflicts excluded."
    )
    return dict(zip(resolved['canonical_smiles'], resolved['toxicity_score'])), summary


class GraphCache:
    """Reuse immutable SMILES graphs across train/validation/test loaders."""
    def __init__(
        self,
        feature_schema: str,
        include_motif_features: bool = False,
        include_fingerprint_features: bool = False,
    ) -> None:
        self.feature_schema = feature_schema
        self.include_motif_features = include_motif_features
        self.include_fingerprint_features = include_fingerprint_features
        self._graphs: dict[str, Any] = {}
        self.hits = 0
        self.misses = 0

    def get(self, smiles: str):
        key = smiles.strip() if isinstance(smiles, str) else str(smiles)
        if key in self._graphs:
            self.hits += 1
            graph = self._graphs[key]
        else:
            self.misses += 1
            graph = smiles_to_graph(
                key,
                feature_schema=self.feature_schema,
                include_motif_features=self.include_motif_features,
                include_fingerprint_features=self.include_fingerprint_features,
            )
            self._graphs[key] = graph
        return graph.clone() if graph is not None else None

    def summary(self) -> dict[str, Any]:
        requests = self.hits + self.misses
        return {
            'feature_schema': self.feature_schema,
            'include_motif_features': self.include_motif_features,
            'include_fingerprint_features': self.include_fingerprint_features,
            'unique_smiles_cached': len(self._graphs),
            'graph_requests': requests,
            'cache_hits': self.hits,
            'cache_misses': self.misses,
            'cache_hit_rate': self.hits / requests if requests else None,
        }


class AuditDDIDataset(Dataset):
    """Graph pairs plus provenance retained for later prediction artifacts."""

    def __init__(
        self,
        dataframe: pd.DataFrame,
        toxicity_lookup: dict[str, float],
        source_col: str = 'source',
        target_col: str = 'target',
        label_col: str = 'label',
        graph_cache: GraphCache | None = None,
        neighbor_memory: AuditableNeighborMemory | None = None,
        exclude_query_pair_from_memory: bool = False,
        source_feature_lookup: dict[str, np.ndarray] | None = None,
        seven_branch_feature_lookup: dict[str, dict[str, tuple[np.ndarray, float]]] | None = None,
    ) -> None:
        super().__init__()
        self.records = []
        self.metadata: list[dict[str, Any]] = []
        self.skipped_count = 0
        self.neighbor_memory = neighbor_memory
        self.source_feature_lookup = source_feature_lookup
        self.seven_branch_feature_lookup = seven_branch_feature_lookup
        self.graph_cache = graph_cache or GraphCache(
            FEATURE_SCHEMA,
            include_motif_features=USE_MOTIF_FEATURES,
            include_fingerprint_features=USE_FINGERPRINT_FEATURES,
        )
        for row in dataframe.itertuples(index=False):
            source = getattr(row, source_col)
            target = getattr(row, target_col)
            label = float(getattr(row, label_col))
            # Validate structures now, but do not retain two cloned graph
            # objects for every pair in every split. The pair tables can have
            # hundreds of thousands of rows, while the molecular cache only
            # needs one base graph per unique structure. ``get`` creates the
            # pair graphs lazily when a batch is requested.
            graph_a = self.graph_cache.get(source)
            graph_b = self.graph_cache.get(target)
            if graph_a is None or graph_b is None:
                self.skipped_count += 1
                continue
            c_src = canonicalize(source)
            toxicity_a = toxicity_lookup.get(c_src) if c_src is not None else None
            c_tgt = canonicalize(target)
            toxicity_b = toxicity_lookup.get(c_tgt) if c_tgt is not None else None
            toxicity_a_known = float(toxicity_a is not None)
            toxicity_b_known = float(toxicity_b is not None)

            record_items = [
                source,
                target,
                0.0 if toxicity_a is None else toxicity_a,
                0.0 if toxicity_b is None else toxicity_b,
                toxicity_a_known,
                toxicity_b_known,
                label,
            ]
            if neighbor_memory is not None:
                mem_scores = neighbor_memory.score_pair_memory(
                    source,
                    target,
                    exclude_query_pair=exclude_query_pair_from_memory,
                )
                mem_feature = torch.tensor([
                    mem_scores['neighbor_density'],
                    mem_scores['max_support'],
                    mem_scores['structural_confidence'],
                ], dtype=torch.float32)
                record_items.append(mem_feature)

            self.records.append(tuple(record_items))
            self.metadata.append(
                {
                    'source': source,
                    'target': target,
                    'label': label,
                    'label_evidence': getattr(row, 'label_evidence', 'unknown'),
                }
            )
        print(f'Built dataset: {len(self.records)} valid pairs; {self.skipped_count} skipped.')

    def len(self) -> int:
        return len(self.records)

    def get(self, idx: int):
        source, target, toxicity_a, toxicity_b, toxicity_a_known, toxicity_b_known, label, *extra = self.records[idx]
        graph_a = self.graph_cache.get(source)
        graph_b = self.graph_cache.get(target)
        if graph_a is None or graph_b is None:
            raise RuntimeError('A molecular graph became unavailable after dataset validation.')
        if self.source_feature_lookup is not None:
            # GraphCache returns fresh clones, so attaching profiles cannot
            # mutate its reusable per-structure graph objects.
            source_key = canonicalize(source)
            target_key = canonicalize(target)
            profile_a = self.source_feature_lookup.get(source_key)
            profile_b = self.source_feature_lookup.get(target_key)
            profile_a = (
                np.zeros(SEVEN_SOURCE_FEATURE_DIM, dtype=np.float32)
                if profile_a is None else profile_a
            )
            profile_b = (
                np.zeros(SEVEN_SOURCE_FEATURE_DIM, dtype=np.float32)
                if profile_b is None else profile_b
            )
            graph_a.source_features = torch.as_tensor(profile_a, dtype=torch.float32)
            graph_b.source_features = torch.as_tensor(profile_b, dtype=torch.float32)
            graph_a.source_profile_mask = torch.tensor([float(np.any(profile_a[-3:]))], dtype=torch.float32)
            graph_b.source_profile_mask = torch.tensor([float(np.any(profile_b[-3:]))], dtype=torch.float32)
        if self.seven_branch_feature_lookup is not None:
            source_key = canonicalize(source)
            target_key = canonicalize(target)
            for branch in SEVEN_BRANCH_NAMES:
                width = SEVEN_BRANCH_DIMENSIONS[branch]
                for graph, key in ((graph_a, source_key), (graph_b, target_key)):
                    item = self.seven_branch_feature_lookup.get(key, {}).get(branch) if key else None
                    if item is None:
                        vector = np.zeros(width, dtype=np.float32)
                        available = 0.0
                    else:
                        vector, available = item
                    setattr(graph, f'{branch}_features', torch.as_tensor(vector, dtype=torch.float32))
                    setattr(graph, f'{branch}_mask', torch.tensor([available], dtype=torch.float32))
        return (
            graph_a,
            graph_b,
            toxicity_a,
            toxicity_b,
            toxicity_a_known,
            toxicity_b_known,
            label,
            *extra,
        )


PxDDIDataset = AuditDDIDataset


def collate_fn(batch):
    graph_a = [item[0] for item in batch]
    graph_b = [item[1] for item in batch]
    toxicity_a = torch.tensor([item[2] for item in batch], dtype=torch.float)
    toxicity_b = torch.tensor([item[3] for item in batch], dtype=torch.float)
    toxicity_a_known = torch.tensor([item[4] for item in batch], dtype=torch.float)
    toxicity_b_known = torch.tensor([item[5] for item in batch], dtype=torch.float)
    labels = torch.tensor([item[6] for item in batch], dtype=torch.float)
    if len(batch[0]) > 7:
        mem_features = torch.tensor(np.array([item[7] for item in batch]), dtype=torch.float)
        return (
            Batch.from_data_list(graph_a),
            Batch.from_data_list(graph_b),
            toxicity_a,
            toxicity_b,
            toxicity_a_known,
            toxicity_b_known,
            labels,
            mem_features,
        )
    return (
        Batch.from_data_list(graph_a),
        Batch.from_data_list(graph_b),
        toxicity_a,
        toxicity_b,
        toxicity_a_known,
        toxicity_b_known,
        labels,
    )


def build_loader(
    dataframe: pd.DataFrame,
    toxicity_lookup: dict[str, float],
    batch_size: int = BATCH_SIZE,
    shuffle: bool = True,
    graph_cache: GraphCache | None = None,
    generator_seed: int = MODEL_SEED,
    neighbor_memory: AuditableNeighborMemory | None = None,
    exclude_query_pair_from_memory: bool = False,
    source_feature_lookup: dict[str, np.ndarray] | None = None,
    seven_branch_feature_lookup: dict[str, dict[str, tuple[np.ndarray, float]]] | None = None,
) -> DataLoader:
    dataset = AuditDDIDataset(
        dataframe,
        toxicity_lookup,
        graph_cache=graph_cache,
        neighbor_memory=neighbor_memory,
        exclude_query_pair_from_memory=exclude_query_pair_from_memory,
        source_feature_lookup=source_feature_lookup,
        seven_branch_feature_lookup=seven_branch_feature_lookup,
    )
    generator = torch.Generator()
    generator.manual_seed(generator_seed)
    return DataLoader(
        dataset,
        batch_size=batch_size,
        shuffle=shuffle,
        collate_fn=collate_fn,
        generator=generator if shuffle else None,
    )


def multi_task_loss(
    risk_prediction,
    toxicity_a_prediction,
    toxicity_b_prediction,
    risk_label,
    toxicity_a_label,
    toxicity_b_label,
    toxicity_a_known,
    toxicity_b_known,
    toxicity_loss_weight: float = TOXICITY_LOSS_WEIGHT,
):
    # All three model heads return raw logits.  Applying BCELoss to the
    # auxiliary heads would both fail for valid logits outside [0, 1] and use
    # a different loss contract from the interaction head.
    bce_with_logits = torch.nn.BCEWithLogitsLoss(reduction='none')
    ddi_loss = bce_with_logits(risk_prediction, risk_label).mean()
    toxicity_a_loss = (
        bce_with_logits(toxicity_a_prediction, toxicity_a_label) * toxicity_a_known
    ).sum() / (toxicity_a_known.sum() + 1e-8)
    toxicity_b_loss = (
        bce_with_logits(toxicity_b_prediction, toxicity_b_label) * toxicity_b_known
    ).sum() / (toxicity_b_known.sum() + 1e-8)
    return ddi_loss + toxicity_loss_weight * (toxicity_a_loss + toxicity_b_loss)


def train_one_epoch(model, loader, optimizer, scaler) -> float:
    if len(loader) == 0:
        raise ValueError('Training loader is empty after SMILES validation.')
    model.train()
    total_loss = 0.0
    for batch_items in loader:
        if len(batch_items) > 7:
            graph_a, graph_b, toxicity_a, toxicity_b, toxicity_a_known, toxicity_b_known, labels, mem_feat = batch_items
            mem_feat = mem_feat.to(DEVICE)
        else:
            graph_a, graph_b, toxicity_a, toxicity_b, toxicity_a_known, toxicity_b_known, labels = batch_items
            mem_feat = None
        graph_a, graph_b = graph_a.to(DEVICE), graph_b.to(DEVICE)
        toxicity_a = toxicity_a.to(DEVICE)
        toxicity_b = toxicity_b.to(DEVICE)
        toxicity_a_known = toxicity_a_known.to(DEVICE)
        toxicity_b_known = toxicity_b_known.to(DEVICE)
        labels = labels.to(DEVICE)
        optimizer.zero_grad()
        if scaler is not None:
            with torch.amp.autocast('cuda'):
                risk, prediction_a, prediction_b = model(graph_a, graph_b, memory_features=mem_feat)
                loss = multi_task_loss(
                    risk, prediction_a, prediction_b, labels,
                    toxicity_a, toxicity_b, toxicity_a_known, toxicity_b_known,
                )
            scaler.scale(loss).backward()
            scaler.step(optimizer)
            scaler.update()
        else:
            risk, prediction_a, prediction_b = model(graph_a, graph_b, memory_features=mem_feat)
            loss = multi_task_loss(
                risk, prediction_a, prediction_b, labels,
                toxicity_a, toxicity_b, toxicity_a_known, toxicity_b_known,
            )
            loss.backward()
            optimizer.step()
        total_loss += float(loss.item())
    return total_loss / len(loader)


def evaluate_one_epoch_loss(model, loader) -> float:
    """Compute the same multitask BCE objective on the validation loader."""
    if len(loader) == 0:
        raise ValueError('Validation loader is empty after SMILES validation.')
    model.eval()
    total_loss = 0.0
    with torch.no_grad():
        for batch_items in loader:
            if len(batch_items) > 7:
                graph_a, graph_b, toxicity_a, toxicity_b, toxicity_a_known, toxicity_b_known, labels, mem_feat = batch_items
                mem_feat = mem_feat.to(DEVICE)
            else:
                graph_a, graph_b, toxicity_a, toxicity_b, toxicity_a_known, toxicity_b_known, labels = batch_items
                mem_feat = None
            graph_a, graph_b = graph_a.to(DEVICE), graph_b.to(DEVICE)
            toxicity_a = toxicity_a.to(DEVICE)
            toxicity_b = toxicity_b.to(DEVICE)
            toxicity_a_known = toxicity_a_known.to(DEVICE)
            toxicity_b_known = toxicity_b_known.to(DEVICE)
            labels = labels.to(DEVICE)
            risk, prediction_a, prediction_b = model(
                graph_a, graph_b, memory_features=mem_feat
            )
            loss = multi_task_loss(
                risk, prediction_a, prediction_b, labels,
                toxicity_a, toxicity_b, toxicity_a_known, toxicity_b_known,
            )
            total_loss += float(loss.item())
    return total_loss / len(loader)


def collect_predictions(model, loader) -> tuple[np.ndarray, np.ndarray]:
    model.eval()
    predictions, labels = [], []
    with torch.no_grad():
        for batch_items in loader:
            if len(batch_items) > 7:
                graph_a, graph_b, _, _, _, _, batch_labels, mem_feat = batch_items
                mem_feat = mem_feat.to(DEVICE)
            else:
                graph_a, graph_b, _, _, _, _, batch_labels = batch_items
                mem_feat = None
            graph_a, graph_b = graph_a.to(DEVICE), graph_b.to(DEVICE)
            risk, _, _ = model(graph_a, graph_b, memory_features=mem_feat)
            predictions.extend(torch.sigmoid(risk).cpu().numpy())
            labels.extend(batch_labels.numpy())
    return np.asarray(labels, dtype=int), np.asarray(predictions, dtype=float)


def measure_inference_efficiency(model, loader) -> dict[str, Any]:
    """Measure full-loader inference throughput for transparent model comparison.

    The figure includes graph batching and host-to-device transfer because that
    is the practical research inference path.  It is hardware-specific and is
    therefore stored beside GPU/runtime details rather than treated as a
    universal production latency claim.
    """
    if len(loader.dataset) == 0:
        return {
            'status': 'skipped_empty_loader',
            'sample_count': 0,
            'wall_clock_seconds': None,
            'pairs_per_second': None,
            'mean_batch_latency_milliseconds': None,
            'peak_cuda_memory_bytes': None,
        }
    if DEVICE.type == 'cuda':
        torch.cuda.synchronize(DEVICE)
        torch.cuda.reset_peak_memory_stats(DEVICE)
    batch_count = 0
    start = time.perf_counter()
    model.eval()
    with torch.inference_mode():
        for batch_items in loader:
            graph_a = batch_items[0].to(DEVICE)
            graph_b = batch_items[1].to(DEVICE)
            mem_feat = batch_items[7].to(DEVICE) if len(batch_items) > 7 else None
            model(graph_a, graph_b, memory_features=mem_feat)
            batch_count += 1
    if DEVICE.type == 'cuda':
        torch.cuda.synchronize(DEVICE)
    elapsed = time.perf_counter() - start
    sample_count = len(loader.dataset)
    return {
        'status': 'measured',
        'measurement_scope': 'full_loader_inference_including_batching_and_device_transfer',
        'sample_count': sample_count,
        'batch_count': batch_count,
        'wall_clock_seconds': elapsed,
        'pairs_per_second': sample_count / elapsed if elapsed else None,
        'mean_batch_latency_milliseconds': 1000 * elapsed / batch_count
        if batch_count else None,
        'peak_cuda_memory_bytes': torch.cuda.max_memory_allocated(DEVICE)
        if DEVICE.type == 'cuda' else None,
        'interpretation_warning': (
            'Inference efficiency depends on the recorded hardware, batch size, '
            'PyTorch/PyG versions, and whether data are already in memory.'
        ),
    }


def select_validation_threshold(labels: np.ndarray, predictions: np.ndarray) -> float:
    if len(labels) == 0 or len(np.unique(labels)) < 2:
        raise ValueError('Validation split must contain both classes to select a threshold.')
    false_positive_rate, true_positive_rate, thresholds = roc_curve(labels, predictions)
    return float(thresholds[np.argmax(true_positive_rate - false_positive_rate)])


def partition_validation_for_model_selection(
    dataframe: pd.DataFrame,
    seed: int = SPLIT_SEED,
    selection_fraction: float = MODEL_SELECTION_VALIDATION_FRACTION,
    label_column: str = 'label',
) -> tuple[pd.DataFrame, pd.DataFrame, dict[str, Any]]:
    """Make early stopping independent from post-hoc validation decisions.

    Each binary class is shuffled deterministically, then partitioned into a
    model-selection split and a reserved post-hoc split.  The latter retains at
    least three examples per class so calibration, threshold selection, and
    conformal fitting can each use a distinct role.  A small split is an
    explicit error rather than a silent reuse of model-selection examples.
    """
    if label_column not in dataframe:
        raise ValueError(f'Validation frame is missing {label_column!r}.')
    if not 0 < selection_fraction < 1:
        raise ValueError('selection_fraction must lie strictly between zero and one.')
    targets = dataframe[label_column].to_numpy(dtype=int)
    if targets.ndim != 1 or len(targets) == 0:
        raise ValueError('Validation labels must be a non-empty one-dimensional array.')
    if not np.isin(targets, (0, 1)).all() or len(np.unique(targets)) < 2:
        raise ValueError('Validation role partitioning requires both binary classes.')

    generator = np.random.default_rng(seed)
    selection_positions: list[int] = []
    posthoc_positions: list[int] = []
    source_counts: dict[str, int] = {}
    for label in (0, 1):
        positions = np.flatnonzero(targets == label)
        source_counts[str(label)] = len(positions)
        if len(positions) < 4:
            raise ValueError(
                'Validation role partitioning requires at least four examples '
                f'of each class; class {label} has {len(positions)}.'
            )
        shuffled = generator.permutation(positions)
        requested_selection = round(len(shuffled) * selection_fraction)
        # Preserve one row per class for each of the three post-hoc roles.
        selection_count = min(max(1, requested_selection), len(shuffled) - 3)
        selection_positions.extend(shuffled[:selection_count].tolist())
        posthoc_positions.extend(shuffled[selection_count:].tolist())

    selection_positions = sorted(selection_positions)
    posthoc_positions = sorted(posthoc_positions)
    model_selection = dataframe.iloc[selection_positions].copy().reset_index(drop=True)
    posthoc = dataframe.iloc[posthoc_positions].copy().reset_index(drop=True)
    summary = {
        'status': 'stratified_disjoint_model_selection_and_posthoc',
        'independent_from_early_stopping': True,
        'seed': seed,
        'requested_model_selection_fraction': selection_fraction,
        'source_rows': len(dataframe),
        'source_label_counts': source_counts,
        'model_selection_rows': len(model_selection),
        'model_selection_label_counts': {
            str(label): (model_selection[label_column] == label).sum()
            for label in (0, 1)
        },
        'posthoc_rows': len(posthoc),
        'posthoc_label_counts': {
            str(label): (posthoc[label_column] == label).sum()
            for label in (0, 1)
        },
        'posthoc_roles': ('calibration', 'threshold', 'conformal'),
    }
    return model_selection, posthoc, summary


def partition_validation_for_posthoc(
    labels: np.ndarray,
    seed: int = SPLIT_SEED,
) -> dict[str, Any]:
    """Create disjoint calibration, threshold, and conformal validation roles.

    Keeping these roles separate prevents a post-hoc calibrator, decision
    threshold, and conformal nonconformity distribution from each evaluating
    themselves. The input must be the reserved post-hoc validation split, not
    the model-selection split used for early stopping.
    """
    targets = np.asarray(labels, dtype=int)
    if targets.ndim != 1 or len(targets) == 0:
        raise ValueError('Validation labels must be a non-empty one-dimensional array.')
    if not np.isin(targets, (0, 1)).all() or len(np.unique(targets)) < 2:
        raise ValueError('Post-hoc validation partitioning requires both binary classes.')

    class_indices = {label: np.flatnonzero(targets == label) for label in (0, 1)}
    minimum_class_count = min(len(indices) for indices in class_indices.values())
    if minimum_class_count < 3:
        all_indices = np.arange(len(targets), dtype=int)
        return {
            'status': 'reused_validation_insufficient_per_class_count',
            'independent_roles': False,
            'reason': (
                'At least three examples of each class are required for disjoint '
                'calibration, threshold, and conformal roles.'
            ),
            'indices': {
                'calibration': all_indices,
                'threshold': all_indices,
                'conformal': all_indices,
            },
        }

    generator = np.random.default_rng(seed)
    role_indices = {'calibration': [], 'threshold': [], 'conformal': []}
    for label in (0, 1):
        shuffled = generator.permutation(class_indices[label])
        role_sizes = [len(shuffled) // 3] * 3
        for offset in range(len(shuffled) % 3):
            role_sizes[offset] += 1
        start = 0
        for role, role_size in zip(role_indices, role_sizes):
            role_indices[role].extend(shuffled[start:start + role_size].tolist())
            start += role_size
    indices = {
        role: np.asarray(sorted(values), dtype=int)
        for role, values in role_indices.items()
    }
    return {
        'status': 'stratified_disjoint_three_way',
        'independent_roles': True,
        'seed': seed,
        'indices': indices,
    }


def posthoc_validation_partition_summary(
    labels: np.ndarray,
    partition: dict[str, Any],
) -> dict[str, Any]:
    """Produce JSON-safe counts for the three post-hoc validation roles."""
    targets = np.asarray(labels, dtype=int)
    roles = {}
    for role, indices in partition['indices'].items():
        role_labels = targets[indices]
        roles[role] = {
            'rows': len(indices),
            'negative_count': int((role_labels == 0).sum()),
            'positive_count': int((role_labels == 1).sum()),
        }
    return {
        'status': partition['status'],
        'independent_roles': partition['independent_roles'],
        'reason': partition.get('reason'),
        'roles': roles,
    }


def save_posthoc_validation_partition_artifact(
    loader: DataLoader,
    labels: np.ndarray,
    raw_predictions: np.ndarray,
    calibrated_predictions: np.ndarray,
    partition: dict[str, Any],
    artifact_dir: Path,
) -> dict[str, Any]:
    """Save the exact validation roles used by post-hoc analysis."""
    if len(cast(AuditDDIDataset, loader.dataset).metadata) != len(labels):
        raise RuntimeError('Validation provenance does not match post-hoc labels.')
    assignments = np.full(len(labels), 'not_assigned', dtype=object)
    for role, indices in partition['indices'].items():
        if np.any(assignments[indices] != 'not_assigned'):
            assignments[indices] = assignments[indices] + '|' + role
        else:
            assignments[indices] = role
    table = pd.DataFrame(cast(AuditDDIDataset, loader.dataset).metadata)
    table['label'] = labels
    table['raw_prediction_score'] = raw_predictions
    table['calibrated_prediction_score'] = calibrated_predictions
    table['posthoc_validation_role'] = assignments
    table['posthoc_roles_independent'] = partition['independent_roles']
    path = artifact_dir / 'posthoc_validation_partition.csv'
    table.to_csv(path, index=False)
    return {
        **posthoc_validation_partition_summary(labels, partition),
        'path': str(path),
        'sha256': get_file_hash(path),
    }


def should_stop_early(
    epoch: int,
    epochs_without_improvement: int,
    minimum_epochs: int = EARLY_STOPPING_MIN_EPOCHS,
    patience: int = EARLY_STOPPING_PATIENCE,
) -> bool:
    """Return whether a non-improving training run has reached its stop rule."""
    return (
        patience > 0
        and epoch >= minimum_epochs
        and epochs_without_improvement >= patience
    )


def calculate_metrics(
    labels: np.ndarray,
    predictions: np.ndarray,
    threshold: float,
    raw_predictions: np.ndarray | None = None,
) -> dict[str, Any]:
    """Backward-compatible wrapper for the shared rigorous metric set."""
    return calculate_binary_metrics(labels, predictions, threshold, raw_predictions)


def save_prediction_artifact(
    name: str,
    loader: DataLoader,
    labels: np.ndarray,
    raw_predictions: np.ndarray,
    calibrated_predictions: np.ndarray,
    threshold: float,
    prediction_dir: Path,
    calibration: dict[str, Any],
    additional_columns: dict[str, Any] | None = None,
) -> Path:
    metadata = cast(AuditDDIDataset, loader.dataset).metadata
    if len(metadata) != len(labels):
        raise RuntimeError('Prediction provenance does not match the evaluated dataset.')
    table = pd.DataFrame(metadata)
    table['label'] = labels
    table['raw_prediction_score'] = raw_predictions
    table['calibrated_prediction_score'] = calibrated_predictions
    table['prediction_score'] = calibrated_predictions
    table['calibration_status'] = calibration.get('status', 'not_fitted')
    table['calibration_method'] = calibration.get('method')
    table['threshold'] = threshold
    table['predicted_label'] = (calibrated_predictions >= threshold).astype(int)
    for column_name, values in (additional_columns or {}).items():
        if len(values) != len(table):
            raise ValueError(
                f'Additional prediction column {column_name!r} does not match '
                'the evaluated dataset length.'
            )
        table[column_name] = values
    prediction_path = prediction_dir / f'{name.lower().replace(" ", "_")}_predictions.csv'
    table.to_csv(prediction_path, index=False)
    return prediction_path


def generate_candidate_explanation_artifact(
    model: AuditDDIModel,
    evaluation_data: dict[str, dict[str, Any]],
    explanation_dir: Path,
) -> dict[str, Any]:
    """Write a bounded, offline explanation audit for experimental candidates.

    This deliberately runs only when requested.  Occlusion is much slower than
    normal inference, and the output is a research artifact rather than an API
    feature.  A single failed example is captured in the JSON without losing a
    completed training run or its benchmark results.
    """
    if not RUN_CANDIDATE_EXPLANATIONS:
        return {
            'status': 'disabled',
            'reason': 'Set AUDITDDI_RUN_CANDIDATE_EXPLANATIONS=1 to generate a bounded offline audit.',
            'method': EXPLANATION_METHOD,
        }
    if MODEL_ARCHITECTURE == MODEL_ARCHITECTURE_LEGACY:
        return {
            'status': 'not_applicable',
            'reason': (
                'The deployed legacy model keeps its existing API explanation path. '
                'Candidate occlusion artifacts are reserved for experimental architectures.'
            ),
            'method': EXPLANATION_METHOD,
        }

    explanation_dir.mkdir(parents=True, exist_ok=True)
    graph_builder = lambda smiles: smiles_to_graph(
        smiles,
        feature_schema=FEATURE_SCHEMA,
        include_motif_features=USE_MOTIF_FEATURES,
    )
    artifact: dict[str, Any] = {
        'method': EXPLANATION_METHOD,
        'model_architecture': MODEL_ARCHITECTURE,
        'model_seed': MODEL_SEED,
        'split_seed': SPLIT_SEED,
        'uses_raw_model_probabilities': True,
        'scope_limitations': EXPLANATION_LIMITATIONS,
        'samples_per_split_limit': EXPLANATION_SAMPLES_PER_SPLIT,
        'top_k': EXPLANATION_TOP_K,
        'splits': {},
    }
    for split_name, payload in evaluation_data.items():
        loader = payload['loader']
        labels = payload['labels']
        raw_predictions = payload['raw_predictions']
        calibrated_predictions = payload['calibrated_predictions']
        threshold = payload['threshold']
        selected_indices = select_representative_indices(
            labels, calibrated_predictions, threshold, EXPLANATION_SAMPLES_PER_SPLIT
        )
        examples = []
        for index in selected_indices:
            graph_a, graph_b, *_ = loader.dataset[index]
            metadata = cast(AuditDDIDataset, loader.dataset).metadata[index]
            example: dict[str, Any] = {
                'dataset_index': index,
                'source': metadata['source'],
                'target': metadata['target'],
                'label': int(labels[index]),
                'label_evidence': metadata['label_evidence'],
                'raw_prediction_score': float(raw_predictions[index]),
                'calibrated_prediction_score': float(calibrated_predictions[index]),
                'validation_selected_threshold': float(threshold),
                'predicted_label': int(calibrated_predictions[index] >= threshold),
            }
            try:
                example['explanation'] = explain_pair_with_occlusion(
                    model,
                    graph_a,
                    graph_b,
                    metadata['source'],
                    metadata['target'],
                    motif_names=MOTIF_FEATURE_NAMES if USE_MOTIF_FEATURES else (),
                    top_k=EXPLANATION_TOP_K,
                    graph_builder=graph_builder,
                )
                visual_dir = explanation_dir / 'figures' / split_name.lower().replace(' ', '_')
                example_prefix = f'example_{index:05d}'
                source_figure = visual_dir / f'{example_prefix}_drug_a.svg'
                target_figure = visual_dir / f'{example_prefix}_drug_b.svg'
                render_occlusion_svg(
                    metadata['source'],
                    example['explanation']['drug_a']['top_atom_occlusions'],
                    example['explanation']['drug_a']['top_bond_occlusions'],
                    source_figure,
                )
                render_occlusion_svg(
                    metadata['target'],
                    example['explanation']['drug_b']['top_atom_occlusions'],
                    example['explanation']['drug_b']['top_bond_occlusions'],
                    target_figure,
                )
                example['explanation_figures'] = {
                    'drug_a_svg': str(source_figure),
                    'drug_b_svg': str(target_figure),
                }
            except Exception as error:  # Keep a completed candidate run auditable.
                example['explanation_error'] = {
                    'type': type(error).__name__,
                    'message': str(error),
                }
            examples.append(example)
        artifact['splits'][split_name] = {
            'evaluated_rows': len(labels),
            'selected_dataset_indices': selected_indices,
            'examples': examples,
        }

    artifact_path = explanation_dir / 'candidate_occlusion_explanations.json'
    write_json(artifact_path, artifact)
    return {
        'status': 'generated',
        'method': EXPLANATION_METHOD,
        'path': str(artifact_path),
        'sha256': get_file_hash(artifact_path),
        'samples_per_split_limit': EXPLANATION_SAMPLES_PER_SPLIT,
        'top_k': EXPLANATION_TOP_K,
        'scope_limitations': EXPLANATION_LIMITATIONS,
    }


def save_conformal_calibration_artifact(
    conformal: dict[str, Any], uncertainty_dir: Path
) -> dict[str, Any]:
    """Persist the validation nonconformity values behind conformal p-values."""
    if conformal.get('status') != 'fitted':
        return {
            'status': conformal.get('status', 'not_fitted'),
            'path': None,
            'sha256': None,
        }
    uncertainty_dir.mkdir(parents=True, exist_ok=True)
    path = uncertainty_dir / 'conformal_validation_nonconformity.csv'
    pd.DataFrame({
        'validation_nonconformity_score': conformal['validation_nonconformity_scores']
    }).to_csv(path, index=False)
    return {
        'status': 'saved',
        'path': str(path),
        'sha256': get_file_hash(path),
        'rows': len(conformal['validation_nonconformity_scores']),
    }


def _save_figure(figure, destination: Path) -> None:
    figure.savefig(destination.with_suffix('.png'), dpi=180, bbox_inches='tight')
    figure.savefig(destination.with_suffix('.pdf'), bbox_inches='tight')
    plt.close(figure)


def plot_training_curves(history: dict[str, list[float]], figure_dir: Path) -> None:
    figure, axes = plt.subplots(1, 2, figsize=(12, 4.5))
    axes[0].plot(history['epoch'], history['loss'], color='#0072B2', label='Training loss')
    if history.get('val_loss') and np.isfinite(history['val_loss']).any():
        axes[0].plot(
            history['epoch'], history['val_loss'], color='#D55E00',
            label='Validation loss',
        )
        axes[0].legend()
    axes[0].set(title='Training and validation loss', xlabel='Epoch', ylabel='BCE loss')
    axes[0].grid(alpha=0.25)
    metric_lines = (
        ('auroc', 'Model-selection AUROC', '#D55E00'),
        ('average_precision', 'Model-selection PR-AUC', '#CC79A7'),
        ('f1', 'Model-selection F1', '#009E73'),
        ('mcc', 'Model-selection MCC', '#56B4E9'),
        ('balanced_accuracy', 'Model-selection balanced accuracy', '#E69F00'),
    )
    for key, label, color in metric_lines:
        if key in history:
            axes[1].plot(history['epoch'], history[key], color=color, label=label)
    axes[1].set(
        title='Model-selection validation performance',
        xlabel='Epoch',
        ylabel='Score',
        ylim=(0, 1),
    )
    axes[1].legend()
    axes[1].grid(alpha=0.25)
    figure.tight_layout()
    _save_figure(figure, figure_dir / 'training_curves')


def plot_evaluation(
    name: str,
    labels: np.ndarray,
    predictions: np.ndarray,
    metrics: dict[str, Any],
    figure_dir: Path,
    raw_predictions: np.ndarray | None = None,
) -> None:
    figure, axes = plt.subplots(1, 4, figsize=(22, 4.8))
    if metrics['status'] == 'evaluated':
        false_positive_rate, true_positive_rate, _ = roc_curve(labels, predictions)
        precision, recall, _ = precision_recall_curve(labels, predictions)
        axes[0].plot(false_positive_rate, true_positive_rate, color='#0072B2')
        axes[0].plot([0, 1], [0, 1], linestyle='--', color='#777777')
        axes[0].set(
            title=f'{name}: ROC (AUROC={metrics["auroc"]:.3f})',
            xlabel='False positive rate', ylabel='True positive rate', xlim=(0, 1), ylim=(0, 1),
        )
        axes[1].plot(recall, precision, color='#D55E00')
        axes[1].set(
            title=f'{name}: PR (AP={metrics["average_precision"]:.3f})',
            xlabel='Recall', ylabel='Precision', xlim=(0, 1), ylim=(0, 1),
        )
    else:
        message = 'Skipped: split has fewer than two classes.'
        for axis in axes[:3]:
            axis.text(0.5, 0.5, message, ha='center', va='center', wrap=True)
            axis.set_axis_off()

    matrix = np.asarray(metrics['confusion_matrix'])
    image = axes[2].imshow(matrix, cmap='Blues')
    for row in range(2):
        for column in range(2):
            axes[2].text(column, row, str(matrix[row, column]), ha='center', va='center')
    axes[2].set(
        title=f'{name}: confusion matrix\nthreshold={metrics["threshold"]:.3f}',
        xlabel='Predicted label', ylabel='True label',
        xticks=[0, 1], yticks=[0, 1],
        xticklabels=['Unreported', 'Reported'], yticklabels=['Unreported', 'Reported'],
    )
    figure.colorbar(image, ax=axes[2], fraction=0.046, pad=0.04)
    if metrics['status'] == 'evaluated':
        fraction_positive, mean_predicted = calibration_curve(labels, predictions, n_bins=10)
        axes[3].plot(mean_predicted, fraction_positive, marker='o', label='Final score')
        if raw_predictions is not None:
            raw_fraction_positive, raw_mean_predicted = calibration_curve(
                labels, raw_predictions, n_bins=10
            )
            axes[3].plot(
                raw_mean_predicted,
                raw_fraction_positive,
                marker='o',
                linestyle='--',
                label='Raw score',
            )
        axes[3].plot([0, 1], [0, 1], linestyle=':', color='#777777', label='Ideal')
        axes[3].set(
            title=f'{name}: calibration',
            xlabel='Mean predicted score',
            ylabel='Observed reported-pair fraction',
            xlim=(0, 1),
            ylim=(0, 1),
        )
        axes[3].legend()
        axes[3].grid(alpha=0.25)
    else:
        axes[3].set_axis_off()
    figure.tight_layout()
    _save_figure(figure, figure_dir / f'{name.lower().replace(" ", "_")}_evaluation')


def plot_benchmark_comparison(results: dict[str, dict[str, Any]], figure_dir: Path) -> None:
    names = list(results)
    metric_names = [('auroc', 'AUROC'), ('average_precision', 'Average precision'), ('f1', 'F1')]
    x = np.arange(len(names))
    width = 0.24
    figure, axis = plt.subplots(figsize=(10, 5))
    for index, (key, label) in enumerate(metric_names):
        values = [results[name][key] if results[name][key] is not None else np.nan for name in names]
        axis.bar(x + (index - 1) * width, values, width, label=label)
    axis.set(
        title='AuditDDI evaluation by split', xlabel='Evaluation split', ylabel='Score',
        xticks=x, xticklabels=names, ylim=(0, 1),
    )
    axis.legend()
    axis.grid(axis='y', alpha=0.25)
    figure.tight_layout()
    _save_figure(figure, figure_dir / 'benchmark_comparison')


def plot_toxicity_bridge_coverage(summary: dict[str, Any], figure_dir: Path) -> None:
    figure_dir.mkdir(parents=True, exist_ok=True)
    if summary.get('conflict_policy') == 'not_enabled':
        figure, axis = plt.subplots(figsize=(8, 4.8))
        axis.text(
            0.5, 0.55, 'Not applicable', ha='center', va='center',
            fontsize=18, fontweight='bold', transform=axis.transAxes,
        )
        axis.text(
            0.5, 0.43, 'Toxicity bridge disabled for this DDI-only run',
            ha='center', va='center', fontsize=12, transform=axis.transAxes,
        )
        axis.set_axis_off()
        figure.tight_layout()
        _save_figure(figure, figure_dir / 'toxicity_bridge_coverage')
        return
    labels = ['Source rows', 'Mapped rows', 'Unique structures', 'Clean structures']
    values = [
        summary['source_rows'],
        summary['rows_with_canonical_smiles'],
        summary['unique_canonical_structures'],
        summary['resolved_unique_canonical_structures'],
    ]
    figure, axis = plt.subplots(figsize=(8, 4.8))
    bars = axis.bar(labels, values, color=['#0072B2', '#56B4E9', '#E69F00', '#009E73'])
    for bar, value in zip(bars, values):
        axis.text(bar.get_x() + bar.get_width() / 2, value, str(value), ha='center', va='bottom')
    axis.set(title='Toxicity bridge coverage after conflict exclusion', ylabel='Structure count')
    axis.grid(axis='y', alpha=0.25)
    figure.tight_layout()
    _save_figure(figure, figure_dir / 'toxicity_bridge_coverage')


def model_summary(model: AuditDDIModel) -> dict[str, Any]:
    """Return a compact architecture and parameter summary for the run manifest."""
    total_parameters = sum(parameter.numel() for parameter in model.parameters())
    trainable_parameters = sum(
        parameter.numel() for parameter in model.parameters() if parameter.requires_grad
    )
    return {
        'model_class': model.__class__.__name__,
        'encoder_class': model.encoder.__class__.__name__,
        'model_architecture': MODEL_ARCHITECTURE,
        'feature_schema': FEATURE_SCHEMA,
        'input_atom_features': INPUT_FEATURE_DIM,
        'edge_feature_dim': (
            NUM_BOND_FEATURES
            if USES_EDGE_FEATURES else None
        ),
        'use_motif_features': USE_MOTIF_FEATURES,
        'neighbor_memory_training_query_policy': (
            'exclude_exact_query_pair_from_interaction_matrix_v1'
            if USE_NEIGHBOR_MEMORY else None
        ),
        'use_cross_drug_attention': USE_CROSS_DRUG_ATTENTION,
        'use_gene_encoder': USE_SEVEN_SOURCE_FEATURES,
        'gene_feature_dim': SEVEN_SOURCE_FEATURE_DIM if USE_SEVEN_SOURCE_FEATURES else None,
        'use_pdb_encoder': USE_PDB_ENCODER,
        'use_clinical_toxicity': USE_CLINICAL_TOXICITY,
        'cross_drug_attention_type': (
            'pair_isolated_atom_attention_v1'
            if USE_CROSS_DRUG_ATTENTION else None
        ),
        'motif_feature_schema': (
            MOTIF_SCHEMA_SMARTS_COUNTS_V1 if USE_MOTIF_FEATURES else None
        ),
        'motif_feature_dim': MOTIF_FEATURE_DIM if USE_MOTIF_FEATURES else None,
        'motif_hidden_channels': MOTIF_HIDDEN_CHANNELS if USE_MOTIF_FEATURES else None,
        'motif_metadata': motif_metadata() if USE_MOTIF_FEATURES else None,
        'hidden_channels': HIDDEN_CHANNELS,
        'use_chemberta': USE_CHEMBERTA,
        'pair_representation': (
            'graph_embedding_plus_pair_isolated_cross_drug_atom_attention_sum + absolute_difference + toxicity_sum + absolute_toxicity_difference'
            if USE_CROSS_DRUG_ATTENTION and USE_TOXICITY_PAIR_FEATURES
            else 'graph_embedding_plus_pair_isolated_cross_drug_atom_attention_sum + absolute_difference'
            if USE_CROSS_DRUG_ATTENTION
            else
            'graph_embedding_plus_motif_embedding_sum + absolute_difference + toxicity_sum + absolute_toxicity_difference'
            if USE_MOTIF_FEATURES and USE_TOXICITY_PAIR_FEATURES
            else 'graph_embedding_plus_motif_embedding_sum + absolute_difference'
            if USE_MOTIF_FEATURES
            else 'embedding_sum + absolute_embedding_difference + toxicity_sum + absolute_toxicity_difference'
            if USE_TOXICITY_PAIR_FEATURES
            else 'embedding_sum + absolute_embedding_difference'
        ),
        'use_toxicity_pair_features': USE_TOXICITY_PAIR_FEATURES,
        'output_heads': (
            ['interaction_risk', 'drug_a_toxicity', 'drug_b_toxicity']
            if USE_TOXICITY_PAIR_FEATURES or TOXICITY_LOSS_WEIGHT > 0.0
            else ['interaction_risk']
        ),
        'toxicity_prediction_head_used': bool(
            USE_TOXICITY_PAIR_FEATURES or TOXICITY_LOSS_WEIGHT > 0.0
        ),
        'total_parameters': int(total_parameters),
        'trainable_parameters': int(trainable_parameters),
    }


def save_model_layer_summary(model: AuditDDIModel, artifact_dir: Path) -> dict[str, Any]:
    """Write a parameterized-layer table from the actual instantiated model."""
    rows: list[dict[str, Any]] = []
    active_components = {'encoder', 'fp_encoder', 'gene_encoder', 'gene_gate', 'risk_classifier'}
    if USE_CROSS_DRUG_ATTENTION:
        active_components.add('cross_drug_attention')
    if USE_MOTIF_FEATURES:
        active_components.add('motif_encoder')
    if USE_TOXICITY_PAIR_FEATURES or TOXICITY_LOSS_WEIGHT > 0.0:
        active_components.add('toxicity_head')
    for name, module in model.named_modules():
        if not name:
            continue
        direct_parameters = list(module.parameters(recurse=False))
        count = sum(parameter.numel() for parameter in direct_parameters)
        if count == 0:
            continue
        if isinstance(module, nn.Linear):
            dimensions = f'{module.in_features} -> {module.out_features}'
        elif module.__class__.__name__ == 'GATv2Conv':
            dimensions = (
                f'in={module.in_channels}; out={module.out_channels}; '
                f'heads={module.heads}; edge_dim={module.edge_dim}'
            )
        else:
            dimensions = ''
        rows.append({
            'module_path': name,
            'component': name.split('.', 1)[0],
            'layer_type': module.__class__.__name__,
            'DDI_run_status': (
                'active' if name.split('.', 1)[0] in active_components
                else 'inactive_or_optional_not_supplied'
            ),
            'dimensions': dimensions,
            'parameter_shapes': '; '.join(
                str(tuple(parameter.shape)) for parameter in direct_parameters
            ),
            'parameters': count,
            'trainable_parameters': sum(
                parameter.numel() for parameter in direct_parameters
                if parameter.requires_grad
            ),
        })

    total = sum(parameter.numel() for parameter in model.parameters())
    rows.append({
        'module_path': 'TOTAL',
        'component': 'complete_model',
        'layer_type': model.__class__.__name__,
        'DDI_run_status': 'complete_model',
        'dimensions': MODEL_ARCHITECTURE,
        'parameter_shapes': '',
        'parameters': total,
        'trainable_parameters': sum(
            parameter.numel() for parameter in model.parameters()
            if parameter.requires_grad
        ),
    })
    artifact_dir.mkdir(parents=True, exist_ok=True)
    output_path = artifact_dir / 'model_summary_layers.csv'
    table = pd.DataFrame(rows)
    table.to_csv(output_path, index=False)
    print('Model layer summary (parameterized layers):')
    print(table.to_string(index=False))
    return {
        'path': str(output_path),
        'sha256': get_file_hash(output_path),
        'parameterized_layer_rows': len(rows) - 1,
        'active_parameterized_layer_rows': sum(
            row['DDI_run_status'] == 'active' for row in rows[:-1]
        ),
        'inactive_parameterized_layer_rows': sum(
            row['DDI_run_status'] != 'active' for row in rows[:-1]
        ),
        'total_parameters': int(total),
    }


@overload
def _prepare_positive_edges(
    audit_dir: Path,
    sampling_seed: int = ...,
    *,
    return_all_clean_positives: Literal[False] = ...,
) -> tuple[pd.DataFrame, dict[str, Any]]: ...


@overload
def _prepare_positive_edges(
    audit_dir: Path,
    sampling_seed: int = ...,
    *,
    return_all_clean_positives: Literal[True],
) -> tuple[pd.DataFrame, dict[str, Any], pd.DataFrame]: ...


def _prepare_positive_edges(
    audit_dir: Path,
    sampling_seed: int = SPLIT_SEED,
    *,
    return_all_clean_positives: bool = False,
) -> tuple[pd.DataFrame, dict[str, Any]] | tuple[pd.DataFrame, dict[str, Any], pd.DataFrame]:
    """Load audited Drive preparation, with a legacy edge-file fallback.

    The versioned parquet stores integer indices into ``drugs_clean.csv``;
    translate those indices to canonical structures here so the molecular
    trainer consumes the user's current prepared data instead of requiring an
    obsolete, separately generated edge CSV.
    """
    if TWOSIDES_PARQUET.is_file() and TWOSIDES_DRUGS.is_file():
        interactions = pd.read_parquet(TWOSIDES_PARQUET)
        catalogue = pd.read_csv(TWOSIDES_DRUGS)
        required_interactions = {'drug_a', 'drug_b'}
        required_catalogue = {'drug_idx', 'smiles'}
        if not required_interactions.issubset(interactions.columns):
            raise ValueError(
                'Prepared TWOSIDES parquet must contain drug_a and drug_b; '
                f'found {interactions.columns.tolist()}.'
            )
        if not required_catalogue.issubset(catalogue.columns):
            raise ValueError(
                'Prepared TWOSIDES drug catalogue must contain drug_idx and smiles; '
                f'found {catalogue.columns.tolist()}.'
            )
        if catalogue['drug_idx'].duplicated().any():
            raise ValueError('Prepared TWOSIDES drug_idx values are not unique.')
        smiles_by_idx = catalogue.set_index('drug_idx')['smiles']
        drug_a_smiles = interactions['drug_a'].map(smiles_by_idx)
        drug_b_smiles = interactions['drug_b'].map(smiles_by_idx)
        missing_map = drug_a_smiles.isna() | drug_b_smiles.isna()
        if missing_map.any():
            examples = interactions.loc[missing_map, ['drug_a', 'drug_b']].head(5)
            raise ValueError(
                f'{int(missing_map.sum())} prepared TWOSIDES rows reference drug '
                f'indices absent from drugs_clean.csv. Examples: {examples.to_dict("records")}'
            )
        positives = pd.DataFrame({'source': drug_a_smiles, 'target': drug_b_smiles})
    else:
        if not TWOSIDES_EDGES.is_file():
            raise FileNotFoundError(
                'Audited TWOSIDES inputs were not found. Expected '
                f'{TWOSIDES_PARQUET} and {TWOSIDES_DRUGS}. The legacy fallback '
                f'{TWOSIDES_EDGES} is also missing.'
            )
        edges = pd.read_csv(TWOSIDES_EDGES)
        required_columns = {'source', 'target'}
        missing = required_columns.difference(edges.columns)
        if missing:
            raise ValueError(f'TWOSIDES edges are missing required columns: {sorted(missing)}.')
        positives = edges[['source', 'target']].copy()
    positives['label'] = 1.0
    positives = deduplicate_unordered_pairs(positives, 'source', 'target')
    clean_positives, exclusions = filter_graph_compatible_pairs(positives)
    if clean_positives.empty:
        raise ValueError('No graph-compatible positive pairs remain after SMILES validation.')

    audit_dir.mkdir(parents=True, exist_ok=True)
    exclusions_path = audit_dir / 'invalid_smiles_exclusions.csv'
    exclusions.to_csv(exclusions_path, index=False)
    curation_summary = save_counterion_curation_candidates(exclusions, audit_dir)
    sampled = clean_positives.sample(
        n=min(DATA_CAP, len(clean_positives)), random_state=sampling_seed
    ).reset_index(drop=True)
    summary = {
        'raw_unique_positive_pairs': len(positives),
        'excluded_positive_pairs': len(exclusions),
        'clean_positive_pairs': len(clean_positives),
        'sampled_positive_pairs': len(sampled),
        'data_cap': DATA_CAP,
        'exclusion_audit_path': str(exclusions_path),
        'exclusion_audit_sha256': get_file_hash(exclusions_path),
        'counterion_curation': curation_summary,
    }
    write_json(audit_dir / 'input_quality_summary.json', summary)
    print(
        'Positive-pair input audit: '
        f"{summary['raw_unique_positive_pairs']} unique pairs; "
        f"{summary['excluded_positive_pairs']} excluded; "
        f"{summary['sampled_positive_pairs']} used for sampling."
    )
    if return_all_clean_positives:
        return sampled, summary, clean_positives.reset_index(drop=True)
    return sampled, summary


def load_seven_source_feature_lookup() -> tuple[dict[str, np.ndarray], list[str]]:
    """Load CID-audited source profiles indexed by canonical PubChem SMILES."""
    if not USE_SEVEN_SOURCE_FEATURES:
        return {}, []
    with np.load(SOURCE_FEATURE_MATRIX, allow_pickle=False) as source:
        required = {'canonical_smiles', 'features', 'feature_names'}
        missing = required.difference(source.files)
        if missing:
            raise ValueError(f'Source feature matrix is missing arrays: {sorted(missing)}')
        smiles = source['canonical_smiles'].astype(str)
        matrix = source['features'].astype(np.float32)
        names = source['feature_names'].astype(str).tolist()
    if matrix.ndim != 2 or matrix.shape[1] != SEVEN_SOURCE_FEATURE_DIM:
        raise ValueError(
            f'Expected source feature shape [n, {SEVEN_SOURCE_FEATURE_DIM}], got {matrix.shape}.'
        )
    if len(smiles) != len(matrix) or len(names) != matrix.shape[1]:
        raise ValueError('Source feature matrix row/column metadata does not match its shape.')
    if not np.isfinite(matrix).all():
        raise ValueError('Source feature matrix contains NaN or infinite values.')
    profiles: dict[str, np.ndarray] = {}
    for raw_smiles, profile in zip(smiles, matrix):
        key = canonicalize(raw_smiles) if raw_smiles else None
        if key is None:
            continue
        if key in profiles and not np.array_equal(profiles[key], profile):
            profiles[key] = np.maximum(profiles[key], profile)
        else:
            profiles[key] = profile
    if not profiles:
        raise ValueError('No source profiles could be joined to canonical molecular structures.')
    return profiles, names


def load_seven_branch_feature_bundle() -> tuple[
    dict[str, dict[str, tuple[np.ndarray, float]]], dict[str, int], dict[str, list[str]], dict[str, Any]
]:
    """Load and audit the five vector branches accompanying graph and Morgan inputs."""
    if not USE_SEVEN_BRANCH_MODEL:
        return {}, {}, {}, {}
    manifest_path = SEVEN_BRANCH_FEATURE_BUNDLE.with_suffix('.manifest.json')
    bundle_manifest = json.loads(manifest_path.read_text(encoding='utf-8'))
    if bundle_manifest.get('schema') != 'auditddi_seven_branch_feature_bundle_v1':
        raise ValueError('Unsupported seven-branch feature bundle schema.')
    expected_hash = bundle_manifest.get('bundle_sha256')
    if expected_hash and get_file_hash(SEVEN_BRANCH_FEATURE_BUNDLE) != expected_hash:
        raise ValueError('Seven-branch bundle hash does not match its manifest.')
    result: dict[str, dict[str, tuple[np.ndarray, float]]] = {}
    dimensions: dict[str, int] = {}
    feature_names: dict[str, list[str]] = {}
    with np.load(SEVEN_BRANCH_FEATURE_BUNDLE, allow_pickle=False) as data:
        required = {'canonical_smiles'}
        for branch in SEVEN_BRANCH_NAMES:
            required.update({
                f'{branch}_features', f'{branch}_mask', f'{branch}_feature_names'
            })
        missing = required.difference(data.files)
        if missing:
            raise ValueError(f'Seven-branch bundle is missing arrays: {sorted(missing)}.')
        smiles = data['canonical_smiles'].astype(str)
        if smiles.ndim != 1 or len(smiles) != len(set(smiles.tolist())):
            raise ValueError('Seven-branch bundle needs unique one-dimensional canonical_smiles keys.')
        matrices: dict[str, np.ndarray] = {}
        masks: dict[str, np.ndarray] = {}
        for branch in SEVEN_BRANCH_NAMES:
            matrix = data[f'{branch}_features'].astype(np.float32)
            mask = data[f'{branch}_mask'].astype(np.float32).reshape(-1)
            names = data[f'{branch}_feature_names'].astype(str).tolist()
            if matrix.ndim != 2 or matrix.shape[0] != len(smiles) or matrix.shape[1] <= 0:
                raise ValueError(f'Invalid matrix shape for {branch}: {matrix.shape}.')
            if len(mask) != len(smiles) or len(names) != matrix.shape[1]:
                raise ValueError(f'Feature metadata shape mismatch for {branch}.')
            if not np.isfinite(matrix).all() or not np.isin(mask, [0.0, 1.0]).all():
                raise ValueError(f'{branch} values or availability mask are invalid.')
            if not np.any(mask == 1.0):
                raise ValueError(f'{branch} has no observed drug features; refusing empty branch.')
            # Masked values are normalized to zero; the mask remains a distinct input.
            matrix[mask == 0.0] = 0.0
            matrices[branch] = matrix
            masks[branch] = mask
            dimensions[branch] = int(matrix.shape[1])
            feature_names[branch] = names
        for index, raw_smiles in enumerate(smiles):
            key = canonicalize(raw_smiles) if raw_smiles else None
            if key is None:
                continue
            if key in result:
                raise ValueError(f'Duplicate canonical drug identity in seven-branch bundle: {key}.')
            result[key] = {
                branch: (matrices[branch][index], float(masks[branch][index]))
                for branch in SEVEN_BRANCH_NAMES
            }
    if not result:
        raise ValueError('No seven-branch bundle rows map to canonical molecular structures.')
    return result, dimensions, feature_names, bundle_manifest


def load_ddinter_known_smiles_pairs() -> pd.DataFrame:
    """Map audited DDInter positives onto the TWOSIDES structure universe."""
    if not (USE_SEVEN_SOURCE_FEATURES or USE_SEVEN_BRANCH_MODEL):
        return pd.DataFrame(columns=['source', 'target'])
    pairs_path = SOURCE_BUNDLE / 'ddinter_pairs.csv'
    if not pairs_path.is_file() or not TWOSIDES_DRUGS.is_file():
        raise FileNotFoundError(
            'Build processed/auditddi_v2/ddinter_pairs.csv and retain the '
            'processed/twosides_v1/drugs_clean.csv before seven-source training.'
        )
    pairs = pd.read_csv(pairs_path)
    catalogue = pd.read_csv(TWOSIDES_DRUGS)
    if not {'pair_a', 'pair_b'}.issubset(pairs.columns) or not {'drug_idx', 'smiles'}.issubset(catalogue.columns):
        raise ValueError('DDInter pair file or TWOSIDES drug catalogue has an unexpected schema.')
    smiles_by_idx = catalogue.set_index('drug_idx')['smiles']
    result = pd.DataFrame({
        'source': pd.to_numeric(pairs['pair_a'], errors='coerce').map(smiles_by_idx),
        'target': pd.to_numeric(pairs['pair_b'], errors='coerce').map(smiles_by_idx),
    }).dropna()
    if result.empty:
        raise ValueError('No DDInter pairs map to prepared TWOSIDES molecular structures.')
    result['label'] = 1.0
    return deduplicate_unordered_pairs(result, 'source', 'target')[['source', 'target']]


def main() -> None:
    global CHECKPOINT_PATH, SEVEN_BRANCH_DIMENSIONS
    if DATA_BASE_RESOLUTION_ERROR is not None:
        raise DATA_BASE_RESOLUTION_ERROR
    if USE_SEVEN_BRANCH_MODEL and RESUME_CHECKPOINT_PATH:
        raise ValueError(
            'The seven-branch model has a new architecture and cannot resume a '
            'checkpoint trained with the earlier three-input model. Start a fresh run '
            'using the ChEMBL graph encoder for initialization.'
        )
    if USE_SEVEN_BRANCH_MODEL and TOXICITY_LOSS_WEIGHT != 0.0:
        raise ValueError(
            'The proposed seven-branch task predicts DDI association only; '
            'set AUDITDDI_TOXICITY_LOSS_WEIGHT=0.'
        )
    set_reproducibility(MODEL_SEED)
    print(f'Training on: {DEVICE}')
    if DEVICE.type != 'cuda':
        print('Warning: CUDA is unavailable; Colab GPU is recommended for this run.')

    RUN_ARTIFACTS_DIR.mkdir(parents=True, exist_ok=False)
    figure_dir = RUN_ARTIFACTS_DIR / 'figures'
    prediction_dir = RUN_ARTIFACTS_DIR / 'predictions'
    audit_dir = RUN_ARTIFACTS_DIR / 'audits'
    figure_dir.mkdir()
    prediction_dir.mkdir()

    manifest = build_run_manifest()
    write_json(RUN_ARTIFACTS_DIR / 'run_manifest_initial.json', manifest)

    toxicity_lookup, toxicity_summary = load_toxicity_lookup(audit_dir)
    positives, input_quality_summary, all_clean_positives = cast(
        tuple[pd.DataFrame, dict[str, Any], pd.DataFrame],
        _prepare_positive_edges(
            audit_dir, sampling_seed=SPLIT_SEED, return_all_clean_positives=True
        ),
    )
    source_feature_lookup, source_feature_names = load_seven_source_feature_lookup()
    seven_branch_feature_lookup, SEVEN_BRANCH_DIMENSIONS, seven_branch_feature_names, seven_branch_manifest = (
        load_seven_branch_feature_bundle()
    )
    if USE_SEVEN_BRANCH_MODEL:
        universe_smiles = {
            key
            for raw_smiles in pd.concat(
                [all_clean_positives['source'], all_clean_positives['target']],
                ignore_index=True,
            ).dropna().astype(str).unique()
            if (key := canonicalize(raw_smiles)) is not None
        }
        branch_coverage = {
            branch: int(sum(
                seven_branch_feature_lookup.get(smiles, {}).get(branch, (None, 0.0))[1] > 0
                for smiles in universe_smiles
            ))
            for branch in SEVEN_BRANCH_NAMES
        }
        missing_universe_branches = [
            branch for branch, count in branch_coverage.items() if count == 0
        ]
        if missing_universe_branches:
            raise ValueError(
                'Seven-branch data has no observed drug matched to the TWOSIDES '
                f'drug universe for: {missing_universe_branches}.'
            )
        write_json(audit_dir / 'seven_branch_feature_coverage.json', {
            'schema': 'auditddi_seven_branch_feature_coverage_v1',
            'bundle_manifest': seven_branch_manifest,
            'dimensions': SEVEN_BRANCH_DIMENSIONS,
            'feature_names': seven_branch_feature_names,
            'bundle_drugs': len(seven_branch_feature_lookup),
            'twosides_drug_universe': len(universe_smiles),
            'observed_twosides_drugs_by_branch': branch_coverage,
            'twosides_drug_coverage_by_branch': {
                branch: count / len(universe_smiles) if universe_smiles else 0.0
                for branch, count in branch_coverage.items()
            },
            'note': 'Observed-row masks are passed into the corresponding encoder.',
        })
        print('Seven-branch TWOSIDES drug coverage:', {
            branch: f'{count}/{len(universe_smiles)}'
            for branch, count in branch_coverage.items()
        })
    ddinter_known_pairs = load_ddinter_known_smiles_pairs()
    all_known_reported_pairs = pd.concat(
        [all_clean_positives[['source', 'target']], ddinter_known_pairs],
        ignore_index=True,
    ).drop_duplicates().reset_index(drop=True)
    if USE_SEVEN_SOURCE_FEATURES:
        input_quality_summary['ddinter_known_pairs_excluded_from_negative_sampling'] = int(
            len(ddinter_known_pairs)
        )
        input_quality_summary['source_feature_profile_count'] = len(source_feature_lookup)
        input_quality_summary['source_feature_names'] = source_feature_names
        write_json(audit_dir / 'input_quality_summary.json', input_quality_summary)
    if EVALUATION_PROTOCOL == 'scaffold_disjoint':
        if NEGATIVE_SAMPLING_PROTOCOL != 'legacy_pre_split_v1':
            raise ValueError(
                'Scaffold-disjoint evaluation has its own split geometry and currently '
                'requires PXDDI_NEGATIVE_SAMPLING_PROTOCOL=legacy_pre_split_v1. '
                'Do not compare it directly with standard split-aware results.'
            )
        full_dataset = build_binary_pair_dataset(
            positives, source_col='source', target_col='target', neg_ratio=1.0, seed=SPLIT_SEED,
            negative_sampling_strategy=NEGATIVE_SAMPLING_STRATEGY,
            known_reported_positive_pairs=all_known_reported_pairs,
            negative_label_evidence=NEGATIVE_LABEL_MEANING,
        )
        dataset_summary = {
            'protocol': 'legacy_pre_split_v1_scaffold_only',
            'effective_positive_pairs': (full_dataset['label'] == 1.0).sum(),
            'sampled_unreported_negative_pairs': (full_dataset['label'] == 0.0).sum(),
            'total_pair_rows_before_split': len(full_dataset),
            'negative_label_meaning': NEGATIVE_LABEL_MEANING,
        }
        from data_prep.scaffold_splits import create_scaffold_disjoint_splits

        splits, scaffold_audit = create_scaffold_disjoint_splits(
            full_dataset, drug_a_col='source', drug_b_col='target', seed=SPLIT_SEED
        )
        train_split_key = 'scaffold_train'
        validation_split_key = 'scaffold_validation'
        posthoc_validation_split_key = 'scaffold_posthoc_validation'
        test_split_keys = {'Scaffold-disjoint': 'scaffold_test'}
        evaluation_protocol_summary: dict[str, Any] = {
            'name': 'scaffold_disjoint',
            **scaffold_audit,
        }
        write_json(audit_dir / 'scaffold_split_audit.json', evaluation_protocol_summary)
    else:
        if NEGATIVE_SAMPLING_PROTOCOL == 'split_aware_standard_v1':
            splits, dataset_summary = create_split_aware_binary_splits(
                positives,
                known_reported_positive_pairs=all_known_reported_pairs,
                source_col='source',
                target_col='target',
                seed=SPLIT_SEED,
                negative_sampling_strategy=NEGATIVE_SAMPLING_STRATEGY,
                negative_label_evidence=NEGATIVE_LABEL_MEANING,
            )
        else:
            full_dataset = build_binary_pair_dataset(
                positives, source_col='source', target_col='target', neg_ratio=1.0, seed=SPLIT_SEED,
                negative_sampling_strategy=NEGATIVE_SAMPLING_STRATEGY,
                known_reported_positive_pairs=all_known_reported_pairs,
                negative_label_evidence=NEGATIVE_LABEL_MEANING,
            )
            dataset_summary = {
                'protocol': 'legacy_pre_split_v1',
                'effective_positive_pairs': (full_dataset['label'] == 1.0).sum(),
                'sampled_unreported_negative_pairs': (full_dataset['label'] == 0.0).sum(),
                'total_pair_rows_before_split': len(full_dataset),
                'negative_label_meaning': NEGATIVE_LABEL_MEANING,
            }
            splits = create_splits(
                full_dataset, drug_a_col='source', drug_b_col='target', seed=SPLIT_SEED
            )
        train_split_key = 'transductive_train'
        validation_split_key = 'validation'
        posthoc_validation_split_key = 'posthoc_validation'
        test_split_keys = {
            'Transductive': 'transductive_test',
            'S1': 's1_test',
            'S2': 's2_test',
            'S1-dev': 's1_dev',
            'S2-dev': 's2_dev',
        }
        evaluation_protocol_summary: dict[str, Any] = {
            'name': 'standard_transductive_s1_s2',
            'interpretation_warning': (
                'Standard results include a transductive split and drug-identity '
                'cold-start S1/S2 partitions. Run scaffold-disjoint evaluation '
                'separately; it requires a distinct training partition.'
            ),
        }
    write_json(audit_dir / 'dataset_summary.json', dataset_summary)
    model_selection_validation, posthoc_validation, validation_role_partition = (
        partition_validation_for_model_selection(
            splits[validation_split_key],
            seed=SPLIT_SEED,
        )
    )
    # Retain the conventional ``validation`` key for compatibility with the
    # experiment suite. It now means model-selection validation only.
    splits[validation_split_key] = model_selection_validation
    splits[posthoc_validation_split_key] = posthoc_validation
    evaluation_protocol_summary['validation_role_partition'] = validation_role_partition
    split_manifest = save_split_manifests(splits, RUN_ARTIFACTS_DIR)

    graph_cache = GraphCache(
        FEATURE_SCHEMA,
        include_motif_features=USE_MOTIF_FEATURES,
        include_fingerprint_features=USE_FINGERPRINT_FEATURES,
    )
    neighbor_memory = None
    if USE_NEIGHBOR_MEMORY:
        train_df = splits[train_split_key]
        neighbor_memory = AuditableNeighborMemory(k_neighbors=5)
        sources = train_df['source'].tolist()
        targets = train_df['target'].tolist()
        labels = train_df['label'].tolist()
        mem_fit_info = neighbor_memory.fit(sources, targets, labels)
        print(
            'AuditDDI: Fitted AuditableNeighborMemory on '
            f"{mem_fit_info['unique_training_drugs']} unique training drugs."
        )

    train_loader = build_loader(
        splits[train_split_key],
        toxicity_lookup,
        shuffle=True,
        graph_cache=graph_cache,
        neighbor_memory=neighbor_memory,
        # Training rows helped construct the memory. Excluding their exact
        # pair entry prevents the memory from encoding their own label.
        exclude_query_pair_from_memory=USE_NEIGHBOR_MEMORY,
        source_feature_lookup=source_feature_lookup if USE_SEVEN_SOURCE_FEATURES else None,
        seven_branch_feature_lookup=seven_branch_feature_lookup if USE_SEVEN_BRANCH_MODEL else None,
    )
    validation_loader = build_loader(
        splits[validation_split_key],
        toxicity_lookup,
        shuffle=False,
        graph_cache=graph_cache,
        neighbor_memory=neighbor_memory,
        source_feature_lookup=source_feature_lookup if USE_SEVEN_SOURCE_FEATURES else None,
        seven_branch_feature_lookup=seven_branch_feature_lookup if USE_SEVEN_BRANCH_MODEL else None,
    )
    posthoc_validation_loader = build_loader(
        splits[posthoc_validation_split_key],
        toxicity_lookup,
        shuffle=False,
        graph_cache=graph_cache,
        neighbor_memory=neighbor_memory,
        source_feature_lookup=source_feature_lookup if USE_SEVEN_SOURCE_FEATURES else None,
        seven_branch_feature_lookup=seven_branch_feature_lookup if USE_SEVEN_BRANCH_MODEL else None,
    )
    test_loaders = {
        name: build_loader(
            splits[split_key],
            toxicity_lookup,
            shuffle=False,
            graph_cache=graph_cache,
            neighbor_memory=neighbor_memory,
            source_feature_lookup=source_feature_lookup if USE_SEVEN_SOURCE_FEATURES else None,
            seven_branch_feature_lookup=seven_branch_feature_lookup if USE_SEVEN_BRANCH_MODEL else None,
        )
        for name, split_key in test_split_keys.items()
    }
    all_loaders = {
        'train': train_loader,
        'model_selection_validation': validation_loader,
        'posthoc_validation': posthoc_validation_loader,
        **test_loaders,
    }
    unexpected_skips = {
        name: cast(AuditDDIDataset, loader.dataset).skipped_count
        for name, loader in all_loaders.items()
        if cast(AuditDDIDataset, loader.dataset).skipped_count
    }
    if unexpected_skips:
        raise RuntimeError(
            'Graph validation changed between the pre-split audit and dataset construction: '
            f'{unexpected_skips}. Review the input audit before training.'
        )
    validation_labels = np.asarray([record['label'] for record in cast(AuditDDIDataset, validation_loader.dataset).metadata])
    if len(validation_labels) == 0 or len(np.unique(validation_labels)) < 2:
        raise ValueError(
            'Model-selection validation is unusable after SMILES validation; '
            'adjust the data split.'
        )
    posthoc_validation_labels = np.asarray([
        record['label'] for record in cast(AuditDDIDataset, posthoc_validation_loader.dataset).metadata
    ])
    if len(posthoc_validation_labels) == 0 or len(np.unique(posthoc_validation_labels)) < 2:
        raise ValueError(
            'Posthoc validation is unusable after SMILES validation; adjust the data split.'
        )

    if USE_SEVEN_BRANCH_MODEL:
        model = SevenBranchDDIModel(
            in_channels=INPUT_FEATURE_DIM,
            edge_feature_dim=NUM_BOND_FEATURES,
            hidden_channels=HIDDEN_CHANNELS,
            branch_dimensions=SEVEN_BRANCH_DIMENSIONS,
        ).to(DEVICE)
    else:
        model = AuditDDIModel(
            in_channels=INPUT_FEATURE_DIM,
            hidden_channels=HIDDEN_CHANNELS,
            use_chemberta=USE_CHEMBERTA,
            architecture_version=MODEL_ARCHITECTURE,
            edge_feature_dim=(
                NUM_BOND_FEATURES
                if USES_EDGE_FEATURES else None
            ),
            use_toxicity_pair_features=USE_TOXICITY_PAIR_FEATURES,
            gene_feature_dim=SEVEN_SOURCE_FEATURE_DIM if USE_SEVEN_SOURCE_FEATURES else 50,
            gene_hidden_channels=64,
            use_gene_encoder=USE_SEVEN_SOURCE_FEATURES,
            use_pdb_encoder=USE_PDB_ENCODER,
            use_clinical_toxicity=USE_CLINICAL_TOXICITY,
            motif_feature_dim=MOTIF_FEATURE_DIM if USE_MOTIF_FEATURES else None,
            motif_hidden_channels=MOTIF_HIDDEN_CHANNELS if USE_MOTIF_FEATURES else None,
            use_neighbor_memory=USE_NEIGHBOR_MEMORY,
        ).to(DEVICE)
    pretraining_initialization: dict[str, Any] | None = None
    if PRETRAINED_ENCODER_PATH is not None:
        pretraining_initialization = load_pretrained_edge_aware_encoder(
            cast(EdgeAwareMolecularEncoder, model.encoder),
            PRETRAINED_ENCODER_PATH,
            expected_in_channels=INPUT_FEATURE_DIM,
            expected_edge_feature_dim=NUM_BOND_FEATURES,
            expected_hidden_channels=HIDDEN_CHANNELS,
            expected_split_audit={
                'twosides_edges_sha256': get_file_hash(
                    TWOSIDES_PARQUET if TWOSIDES_PARQUET.is_file() else TWOSIDES_EDGES
                ),
                'data_cap': DATA_CAP,
                'split_seed': SPLIT_SEED,
                'negative_sampling_strategy': NEGATIVE_SAMPLING_STRATEGY,
                'negative_sampling_protocol': NEGATIVE_SAMPLING_PROTOCOL,
            },
            map_location=DEVICE,
        )
        pretraining_initialization['sha256'] = get_file_hash(PRETRAINED_ENCODER_PATH)
        print(
            'Initialized edge-aware encoder from audited ChEMBL pretraining: '
            f'{PRETRAINED_ENCODER_PATH}'
        )
    warm_start_checkpoint: dict[str, Any] | None = None
    warm_start_info: dict[str, Any] | None = None
    if RESUME_CHECKPOINT_PATH:
        warm_start_checkpoint, warm_start_info = load_warm_start_checkpoint(
            RESUME_CHECKPOINT_PATH,
            model,
            manifest,
            split_manifest,
            RESUME_AFTER_EPOCH,
        )
        print(
            'Warm-started from best saved weights at epoch '
            f'{warm_start_info["checkpoint_epoch"]}; continuing at epoch '
            f'{RESUME_AFTER_EPOCH + 1}. Adam and scheduler state will be reinitialized.'
        )
    optimizer = torch.optim.Adam(model.parameters(), lr=0.001, weight_decay=1e-4)
    scheduler = torch.optim.lr_scheduler.StepLR(optimizer, step_size=20, gamma=0.7)
    if warm_start_info is not None:
        completed_schedule_steps = RESUME_AFTER_EPOCH // scheduler.step_size
        resumed_lr = 0.001 * (scheduler.gamma ** completed_schedule_steps)
        for group in optimizer.param_groups:
            group['lr'] = resumed_lr
            group['initial_lr'] = 0.001
        scheduler.last_epoch = RESUME_AFTER_EPOCH
        scheduler._step_count = RESUME_AFTER_EPOCH + 1
        scheduler._last_lr = [resumed_lr for _ in optimizer.param_groups]
    scaler = torch.amp.GradScaler('cuda') if DEVICE.type == 'cuda' else None
    history = {
        'epoch': [],
        'loss': [],
        'auroc': [],
        'average_precision': [],
        'f1': [],
        'mcc': [],
        'balanced_accuracy': [],
        'val_loss': [],
        'threshold': [],
        'learning_rate': [],
    }
    if warm_start_info is not None and RESUME_HISTORY_PATH:
        resume_history_file = Path(RESUME_HISTORY_PATH)
        if not resume_history_file.is_file():
            raise FileNotFoundError(
                f'Resume history file does not exist: {resume_history_file}'
            )
        history = load_training_history_file(resume_history_file)
        if not history['epoch'] or int(history['epoch'][-1]) != RESUME_AFTER_EPOCH:
            raise ValueError(
                'Resume history must end at AUDITDDI_RESUME_AFTER_EPOCH; '
                f'history ends at {history["epoch"][-1] if history["epoch"] else "empty"}, '
                f'configured after-epoch is {RESUME_AFTER_EPOCH}.'
            )
        warm_start_info['history_source_path'] = str(resume_history_file)
        warm_start_info['history_source_sha256'] = get_file_hash(resume_history_file)
        print(
            f'Loaded {len(history["epoch"])} saved epoch-history rows; '
            'the loss plot will retain that recorded history.'
        )
    elif warm_start_info is not None:
        print(
            'Warning: no AUDITDDI_RESUME_HISTORY_PATH was supplied; this run '
            'will plot only epochs recorded after the warm start.'
        )
    best_auroc = (
        float(warm_start_info['checkpoint_validation_auroc'])
        if warm_start_info is not None else float('-inf')
    )
    best_epoch = (
        int(warm_start_info['checkpoint_epoch'])
        if warm_start_info is not None else 0
    )
    epochs_without_improvement = (
        max(0, RESUME_AFTER_EPOCH - best_epoch)
        if warm_start_info is not None else 0
    )
    stopped_early = False
    if DEVICE.type == 'cuda':
        torch.cuda.reset_peak_memory_stats(DEVICE)
        torch.cuda.synchronize(DEVICE)
    training_started_at = time.perf_counter()
    evaluation_checkpoint: dict[str, Any] = {}
    if EVALUATE_ONLY:
        if not CHECKPOINT_PATH.is_file():
            raise FileNotFoundError(
                'AUDITDDI_EVALUATE_ONLY checkpoint does not exist: '
                f'{CHECKPOINT_PATH}.'
            )
        loaded_eval = torch.load(
            CHECKPOINT_PATH, map_location='cpu', weights_only=False
        )
        if isinstance(loaded_eval, dict):
            evaluation_checkpoint = loaded_eval
        else:
            raise TypeError('Loaded checkpoint must be a dictionary.')
        validate_checkpoint_for_evaluation(
            evaluation_checkpoint, manifest, split_manifest
        )
        print("=" * 72)
        print("  AuditDDI Evaluation Mode: ZERO TRAINING EPOCHS")
        print(f"  Loaded saved checkpoint: {CHECKPOINT_PATH}")
        print("  Evaluating test splits (Transductive, S1 novel, S2 novel)...")
        print("=" * 72)
        stopped_early = True
        history = load_checkpoint_training_history(evaluation_checkpoint)
    else:
        for epoch in range(RESUME_AFTER_EPOCH + 1, EPOCHS + 1):
            loss = train_one_epoch(model, train_loader, optimizer, scaler)
            scheduler.step()
            validation_loss = evaluate_one_epoch_loss(model, validation_loader)
            validation_true, validation_predicted = collect_predictions(model, validation_loader)
            threshold = select_validation_threshold(validation_true, validation_predicted)
            validation_metrics = calculate_metrics(validation_true, validation_predicted, threshold)
            history['epoch'].append(epoch)
            history['loss'].append(loss)
            history['val_loss'].append(validation_loss)
            history['auroc'].append(validation_metrics['auroc'])
            history['average_precision'].append(validation_metrics['average_precision'])
            history['f1'].append(validation_metrics['f1'])
            history['mcc'].append(validation_metrics['mcc'])
            history['balanced_accuracy'].append(validation_metrics['balanced_accuracy'])
            history['threshold'].append(threshold)
            history['learning_rate'].append(float(optimizer.param_groups[0]['lr']))
            # Preserve the live curve if the Colab runtime disconnects.
            live_history_path = RUN_ARTIFACTS_DIR / 'training_history_live.csv'
            temporary_history_path = live_history_path.with_suffix('.csv.tmp')
            pd.DataFrame(history).to_csv(temporary_history_path, index=False)
            temporary_history_path.replace(live_history_path)
            print(
                f'Epoch {epoch}/{EPOCHS}: loss={loss:.4f}; '
                f'val_loss={validation_loss:.4f}; '
                f"selection AUROC={validation_metrics['auroc']:.4f}; "
                f"PR-AUC={validation_metrics['average_precision']:.4f}; "
                f"MCC={validation_metrics['mcc']:.4f}; "
                f"balanced accuracy={validation_metrics['balanced_accuracy']:.4f}; "
                f"F1={validation_metrics['f1']:.4f}; "
                f'LR={optimizer.param_groups[0]["lr"]:.6f}'
            )
            if validation_metrics['auroc'] > best_auroc:
                best_auroc = validation_metrics['auroc']
                best_epoch = epoch
                epochs_without_improvement = 0
                safe_checkpoint_save(
                    {
                        'model_state_dict': model.state_dict(),
                        'hidden_channels': HIDDEN_CHANNELS,
                        'in_channels': INPUT_FEATURE_DIM,
                        'architecture_version': MODEL_ARCHITECTURE,
                        'feature_schema': FEATURE_SCHEMA,
                        'edge_feature_dim': (
                            NUM_BOND_FEATURES
                            if USES_EDGE_FEATURES else None
                        ),
                        'motif_feature_schema': (
                            MOTIF_SCHEMA_SMARTS_COUNTS_V1 if USE_MOTIF_FEATURES else None
                        ),
                        'motif_feature_dim': MOTIF_FEATURE_DIM if USE_MOTIF_FEATURES else None,
                        'motif_hidden_channels': (
                            MOTIF_HIDDEN_CHANNELS if USE_MOTIF_FEATURES else None
                        ),
                        'motif_metadata': motif_metadata() if USE_MOTIF_FEATURES else None,
                        'use_cross_drug_attention': USE_CROSS_DRUG_ATTENTION,
                        'cross_drug_attention_type': (
                            'pair_isolated_atom_attention_v1'
                            if USE_CROSS_DRUG_ATTENTION else None
                        ),
                        'use_fingerprint_features': USE_FINGERPRINT_FEATURES,
                        'use_neighbor_memory': USE_NEIGHBOR_MEMORY,
                        'neighbor_memory_state': (
                            neighbor_memory.export_state() if neighbor_memory is not None else None
                        ),
                        'use_toxicity_pair_features': USE_TOXICITY_PAIR_FEATURES,
                        'use_pdb_encoder': USE_PDB_ENCODER,
                        'use_clinical_toxicity': USE_CLINICAL_TOXICITY,
                        'use_gene_encoder': USE_SEVEN_SOURCE_FEATURES,
                        'gene_feature_dim': SEVEN_SOURCE_FEATURE_DIM if USE_SEVEN_SOURCE_FEATURES else 50,
                        'source_feature_schema': (
                            'auditddi_seven_source_profile_51_v1'
                            if USE_SEVEN_SOURCE_FEATURES else None
                        ),
                        'source_feature_names': source_feature_names if USE_SEVEN_SOURCE_FEATURES else None,
                        'source_feature_lookup': (
                            {smiles: vector.tolist() for smiles, vector in source_feature_lookup.items()}
                            if USE_SEVEN_SOURCE_FEATURES else None
                        ),
                        'seven_branch_dimensions': SEVEN_BRANCH_DIMENSIONS if USE_SEVEN_BRANCH_MODEL else None,
                        'seven_branch_feature_names': seven_branch_feature_names if USE_SEVEN_BRANCH_MODEL else None,
                        'seven_branch_bundle_path': str(SEVEN_BRANCH_FEATURE_BUNDLE) if USE_SEVEN_BRANCH_MODEL else None,
                        'seven_branch_bundle_sha256': (
                            get_file_hash(SEVEN_BRANCH_FEATURE_BUNDLE)
                            if USE_SEVEN_BRANCH_MODEL else None
                        ),
                        'seven_branch_hidden_channels': 64 if USE_SEVEN_BRANCH_MODEL else None,
                        'seven_branch_dropout': 0.25 if USE_SEVEN_BRANCH_MODEL else None,
                        'toxicity_loss_weight': TOXICITY_LOSS_WEIGHT,
                        'toxicity_head_output': 'logits_v1',
                        'use_chemberta': USE_CHEMBERTA,
                        'auroc': float(best_auroc),
                        'model_selection_metric': 'AUROC',
                        'model_selection_split': (
                            f'{validation_split_key}: disjoint model-selection validation '
                            'used for early stopping'
                        ),
                        'epoch': epoch,
                        'data_cap': DATA_CAP,
                        'seed': MODEL_SEED,
                        'model_seed': MODEL_SEED,
                        'split_seed': SPLIT_SEED,
                        'threshold': threshold,
                        'pretraining_initialization': pretraining_initialization,
                        'warm_start_provenance': warm_start_info,
                        'evaluation_provenance': evaluation_checkpoint_provenance(
                            manifest, split_manifest
                        ),
                        'external_overlap_training_split': external_overlap_training_split(
                            split_manifest, train_split_key
                        ),
                        'external_overlap_development_splits': (
                            external_overlap_development_splits(split_manifest)
                        ),
                    },
                    CHECKPOINT_PATH,
                )
            else:
                epochs_without_improvement += 1
            if should_stop_early(epoch, epochs_without_improvement):
                stopped_early = True
                print(
                    'Early stopping: no validation AUROC improvement for '
                    f'{epochs_without_improvement} epochs after epoch {EARLY_STOPPING_MIN_EPOCHS}. '
                    f'Keeping best checkpoint from epoch {best_epoch}.'
                )
                break

        if warm_start_checkpoint is not None and best_epoch == int(warm_start_info['checkpoint_epoch']):
            # No resumed epoch beat the saved best. Publish that audited model
            # under the new output path so downstream finalization sees the
            # selected weights, without overwriting the original checkpoint.
            warm_start_checkpoint['warm_start_provenance'] = warm_start_info
            safe_checkpoint_save(warm_start_checkpoint, CHECKPOINT_PATH)

    if DEVICE.type == 'cuda':
        torch.cuda.synchronize(DEVICE)
    training_efficiency = {
        'measurement_scope': (
            'checkpoint_evaluation_only' if EVALUATE_ONLY
            else 'optimization_and_per_epoch_validation'
        ),
        'wall_clock_seconds': time.perf_counter() - training_started_at,
        'peak_cuda_memory_bytes': torch.cuda.max_memory_allocated(DEVICE)
        if DEVICE.type == 'cuda' else None,
        'recorded_batch_size': BATCH_SIZE,
        'parameter_count': int(sum(parameter.numel() for parameter in model.parameters())),
        'interpretation_warning': (
            'Training efficiency is hardware- and data-size-specific. Compare it '
            'only across runs with the same runtime environment and split manifest.'
        ),
    }

    # Preserve the real convergence record in this run's artifacts. A
    # checkpoint-only evaluation reads the existing history but never rewrites
    # the checkpoint to point at its newly created report copy.
    plot_training_curves(history, figure_dir)
    history_summary = save_training_history(history, RUN_ARTIFACTS_DIR)
    checkpoint: dict[str, Any] = (
        evaluation_checkpoint
        if EVALUATE_ONLY
        else torch.load(CHECKPOINT_PATH, map_location=DEVICE, weights_only=False)
    )
    model.load_state_dict(checkpoint['model_state_dict'])
    model_layer_summary = save_model_layer_summary(model, RUN_ARTIFACTS_DIR)
    validation_true, validation_raw_predictions = collect_predictions(
        model, posthoc_validation_loader
    )
    posthoc_partition = partition_validation_for_posthoc(
        validation_true, seed=SPLIT_SEED
    )
    calibration_indices = posthoc_partition['indices']['calibration']
    threshold_indices = posthoc_partition['indices']['threshold']
    conformal_indices = posthoc_partition['indices']['conformal']
    calibration = fit_platt_calibrator(
        validation_true[calibration_indices],
        validation_raw_predictions[calibration_indices],
        fitted_on=(
            'posthoc_validation_calibration_partition'
            if posthoc_partition['independent_roles']
            else 'reused_validation_insufficient_per_class_count'
        ),
    )
    validation_calibrated_predictions = apply_calibrator(
        validation_raw_predictions, calibration
    )
    conformal = fit_split_conformal_binary(
        validation_true[conformal_indices],
        validation_calibrated_predictions[conformal_indices],
        alpha=CONFORMAL_ALPHA,
        fitted_on=(
            'posthoc_validation_conformal_partition'
            if posthoc_partition['independent_roles']
            else 'reused_validation_insufficient_per_class_count'
        ),
    )
    conformal_artifact = save_conformal_calibration_artifact(
        conformal, RUN_ARTIFACTS_DIR / 'uncertainty'
    )
    posthoc_partition_artifact = save_posthoc_validation_partition_artifact(
        posthoc_validation_loader,
        validation_true,
        validation_raw_predictions,
        validation_calibrated_predictions,
        posthoc_partition,
        RUN_ARTIFACTS_DIR / 'uncertainty',
    )
    training_smiles = {
        metadata[column]
        for metadata in cast(AuditDDIDataset, train_loader.dataset).metadata
        for column in ('source', 'target')
    }
    applicability_domain = MorganApplicabilityDomain(
        minimum_similarity=APPLICABILITY_DOMAIN_MINIMUM_SIMILARITY
    )
    applicability_domain_summary = applicability_domain.fit(training_smiles)
    frozen_threshold = select_validation_threshold(
        validation_true[threshold_indices], validation_calibrated_predictions[threshold_indices]
    )
    if not EVALUATE_ONLY:
        checkpoint['threshold'] = frozen_threshold
        checkpoint['calibration'] = calibration
        checkpoint['toxicity_head_output'] = 'logits_v1'
        checkpoint['conformal'] = conformal
        checkpoint['use_neighbor_memory'] = USE_NEIGHBOR_MEMORY
        checkpoint['neighbor_memory_state'] = (
            neighbor_memory.export_state() if neighbor_memory is not None else None
        )
        checkpoint['applicability_domain'] = applicability_domain.export_checkpoint_state()
        checkpoint['posthoc_validation_partition'] = {
            key: value for key, value in posthoc_partition_artifact.items()
            if key not in {'path', 'sha256'}
        }
        checkpoint['validation_role_partition'] = validation_role_partition
        checkpoint['pretraining_initialization'] = pretraining_initialization
        checkpoint['evaluation_provenance'] = evaluation_checkpoint_provenance(
            manifest, split_manifest
        )
        checkpoint['external_overlap_training_split'] = external_overlap_training_split(
            split_manifest, train_split_key
        )
        checkpoint['external_overlap_development_splits'] = external_overlap_development_splits(
            split_manifest
        )
        checkpoint['training_history'] = history_summary
    checkpoint_hash = persist_finalized_checkpoint(
        checkpoint, CHECKPOINT_PATH, evaluation_only=EVALUATE_ONLY
    )
    validation_prediction_path = save_prediction_artifact(
        'Validation',
        posthoc_validation_loader,
        validation_true,
        validation_raw_predictions,
        validation_calibrated_predictions,
        frozen_threshold,
        prediction_dir,
        calibration,
    )
    validation_prediction_summary = {
        'path': str(validation_prediction_path),
        'sha256': get_file_hash(validation_prediction_path),
        'rows': len(validation_true),
        'purpose': (
            'Raw member scores from validation reserved before training. They were '
            'not used for early stopping; a fixed-split ensemble combines them '
            'before its own calibrator, threshold, and conformal rule are fitted.'
        ),
        'split_role': 'posthoc_validation_reserved_before_training',
    }

    results: dict[str, dict[str, Any]] = {}
    evaluation_data: dict[str, dict[str, Any]] = {}
    for name, loader in test_loaders.items():
        labels, raw_predictions = collect_predictions(model, loader)
        calibrated_predictions = apply_calibrator(raw_predictions, calibration)
        metrics = calculate_metrics(
            labels,
            calibrated_predictions,
            frozen_threshold,
            raw_predictions=raw_predictions,
        )
        conformal_sets = conformal_prediction_sets(calibrated_predictions, conformal)
        applicability_scores = applicability_domain.score_pairs(
            [metadata['source'] for metadata in cast(AuditDDIDataset, loader.dataset).metadata],
            [metadata['target'] for metadata in cast(AuditDDIDataset, loader.dataset).metadata],
        )
        additional_prediction_columns = {
            'predictive_entropy_nats': predictive_entropy(calibrated_predictions),
            'conformal_no_interaction_p_value': conformal_sets['no_interaction_p_value'],
            'conformal_interaction_p_value': conformal_sets['interaction_p_value'],
            'conformal_prediction_set': conformal_sets['prediction_set'],
            'conformal_prediction_set_size': conformal_sets['set_size'],
            'conformal_abstain': conformal_sets['abstain'],
            **applicability_scores,
        }
        prediction_path = save_prediction_artifact(
            name,
            loader,
            labels,
            raw_predictions,
            calibrated_predictions,
            frozen_threshold,
            prediction_dir,
            calibration,
            additional_columns=additional_prediction_columns,
        )
        metrics['prediction_path'] = str(prediction_path)
        metrics['prediction_sha256'] = get_file_hash(prediction_path)
        metrics['skipped_invalid_smiles'] = cast(AuditDDIDataset, loader.dataset).skipped_count
        metrics['test_set_bootstrap_95ci'] = bootstrap_confidence_intervals(
            labels,
            calibrated_predictions,
            frozen_threshold,
            raw_predictions=raw_predictions,
            resamples=BOOTSTRAP_RESAMPLES,
            seed=SPLIT_SEED,
        )
        metrics['uncertainty'] = summarize_conformal_test_labels(labels, conformal_sets)
        metrics['uncertainty'].update({
            'method': conformal['method'],
            'alpha': conformal['alpha'],
            'interpretation_warning': conformal['interpretation_warning'],
        })
        metrics['selective_prediction'] = selective_prediction_summary(
            labels,
            calibrated_predictions,
            frozen_threshold,
            conformal_sets['abstain'],
        )
        metrics['applicability_domain'] = {
            'structural_ood_count': int(applicability_scores['structural_ood_flag'].sum()),
            'structural_ood_rate': float(applicability_scores['structural_ood_flag'].mean()),
            'minimum_tanimoto_similarity': APPLICABILITY_DOMAIN_MINIMUM_SIMILARITY,
            'interpretation_warning': applicability_domain_summary['interpretation_warning'],
        }
        metrics['structural_similarity_slices'] = structural_similarity_slices(
            labels,
            calibrated_predictions,
            frozen_threshold,
            applicability_scores['pair_minimum_nearest_train_tanimoto'],
            raw_predictions=raw_predictions,
        )
        metrics['error_analysis'] = save_confident_error_analysis(
            cast(AuditDDIDataset, loader.dataset).metadata,
            labels,
            raw_predictions,
            calibrated_predictions,
            frozen_threshold,
            RUN_ARTIFACTS_DIR / 'error_analysis',
            name,
            maximum_rows_per_error_type=ERROR_ANALYSIS_MAX_ROWS,
            additional_columns=additional_prediction_columns,
        )
        metrics['inference_efficiency'] = measure_inference_efficiency(model, loader)
        results[name] = metrics
        evaluation_data[name] = {
            'loader': loader,
            'labels': labels,
            'raw_predictions': raw_predictions,
            'calibrated_predictions': calibrated_predictions,
            'threshold': frozen_threshold,
            # SMILES stored for pair-level OOD audit
            'source_smiles': [
                metadata['source']
                for metadata in cast(AuditDDIDataset, loader.dataset).metadata
            ],
            'target_smiles': [
                metadata['target']
                for metadata in cast(AuditDDIDataset, loader.dataset).metadata
            ],
            # Drug-level pair minimum Tanimoto from existing applicability domain
            'pair_min_tanimoto': applicability_scores['pair_minimum_nearest_train_tanimoto'],
        }
        plot_evaluation(
            name,
            labels,
            calibrated_predictions,
            metrics,
            figure_dir,
            raw_predictions=raw_predictions,
        )
    evaluation_metrics_summary = save_evaluation_metrics(results, RUN_ARTIFACTS_DIR)
    plot_benchmark_comparison(results, figure_dir)
    plot_toxicity_bridge_coverage(toxicity_summary, figure_dir)

    # =========================================================================
    # Novelty audits — auto-generate all paper artifact figures and JSONs
    # =========================================================================
    novelty_audit_dir = RUN_ARTIFACTS_DIR / 'novelty_audits'
    novelty_audit_dir.mkdir(parents=True, exist_ok=True)

    # 1. Pair-level applicability domain ──────────────────────────────────────
    training_pairs_source = [
        metadata['source']
        for metadata in cast(AuditDDIDataset, train_loader.dataset).metadata
    ]
    training_pairs_target = [
        metadata['target']
        for metadata in cast(AuditDDIDataset, train_loader.dataset).metadata
    ]
    pair_ood = PairApplicabilityDomain(
        minimum_similarity=APPLICABILITY_DOMAIN_MINIMUM_SIMILARITY
    )
    pair_ood_fit_summary = pair_ood.fit(training_pairs_source, training_pairs_target)
    pair_ood_results: dict[str, Any] = {}
    for split_name, split_data in evaluation_data.items():
        try:
            pair_scores = pair_ood.score_pairs(
                split_data['source_smiles'], split_data['target_smiles']
            )
            pair_ood_summary = pair_ood.summarize(pair_scores)
            pair_ood_results[split_name] = pair_ood_summary
            write_json(
                novelty_audit_dir / f'pair_ood_{split_name.lower().replace("-", "_")}.json',
                pair_ood_summary,
            )
        except Exception as pair_ood_error:
            pair_ood_results[split_name] = {'error': str(pair_ood_error)}
    write_json(
        novelty_audit_dir / 'pair_ood_fit_summary.json',
        {**pair_ood_fit_summary, 'per_split': pair_ood_results},
    )

    # 2. Degradation audit with bootstrap confidence intervals ─────────────────
    degradation = DegradationAudit(n_bootstrap=BOOTSTRAP_RESAMPLES, seed=SPLIT_SEED)
    for split_name, split_data in evaluation_data.items():
        try:
            deg_result = degradation.run(
                labels=split_data['labels'],
                scores=split_data['calibrated_predictions'],
                pair_min_tanimoto=split_data['pair_min_tanimoto'],
                split_name=split_name,
            )
            DegradationAudit.save(
                deg_result,
                novelty_audit_dir
                / f'degradation_{split_name.lower().replace("-", "_")}.json',
            )
        except Exception as deg_error:
            write_json(
                novelty_audit_dir
                / f'degradation_{split_name.lower().replace("-", "_")}_error.json',
                {'error': str(deg_error), 'split': split_name},
            )

    # 3. Reliability diagrams (calibration curves) per split ──────────────────
    reliability_input = {
        sn: {
            'labels': sd['labels'].tolist()
            if hasattr(sd['labels'], 'tolist') else list(sd['labels']),
            'scores': sd['calibrated_predictions'].tolist()
            if hasattr(sd['calibrated_predictions'], 'tolist')
            else list(sd['calibrated_predictions']),
        }
        for sn, sd in evaluation_data.items()
    }
    try:
        reliability_stats = plot_reliability_diagram(
            split_results=reliability_input,
            output_path=novelty_audit_dir / 'reliability_diagram',
            n_bins=10,
        )
        write_json(novelty_audit_dir / 'reliability_stats.json', reliability_stats)
    except Exception as rel_error:
        write_json(
            novelty_audit_dir / 'reliability_error.json',
            {'error': str(rel_error)},
        )
    # =========================================================================

    write_json(RUN_ARTIFACTS_DIR / 'results_summary.json', results)
    explanation_summary = generate_candidate_explanation_artifact(
        model, evaluation_data, RUN_ARTIFACTS_DIR / 'explanations'
    )

    manifest.update({
        'completed_at_utc': datetime.now(timezone.utc).isoformat(),
        'warm_start': warm_start_info,
        'checkpoint': {
            'path': str(CHECKPOINT_PATH),
            'sha256': checkpoint_hash,
            'write_mode': (
                'read_only_checkpoint_evaluation'
                if EVALUATE_ONLY else 'training_posthoc_finalization'
            ),
            'epoch': checkpoint['epoch'],
            'validation_auroc': checkpoint['auroc'],
            'validation_selected_threshold': frozen_threshold,
        },
        'calibration': calibration,
        'validation_predictions': validation_prediction_summary,
        'uncertainty': {
            'conformal': {
                key: value for key, value in conformal.items()
                if key != 'validation_nonconformity_scores'
            },
            'conformal_validation_artifact': conformal_artifact,
            'posthoc_validation_partition': posthoc_partition_artifact,
            'validation_role_partition': validation_role_partition,
            'applicability_domain': applicability_domain_summary,
        },
        'model_summary': model_summary(model),
        'model_layer_summary': model_layer_summary,
        'pretraining_initialization': pretraining_initialization,
        'evaluation_protocol': evaluation_protocol_summary,
        'efficiency': {
            'training': training_efficiency,
            'inference_by_evaluation_split': {
                name: metrics['inference_efficiency'] for name, metrics in results.items()
            },
        },
        'training_history': history_summary,
        'evaluation_metrics': evaluation_metrics_summary,
        'early_stopping': {
            'enabled': EARLY_STOPPING_PATIENCE > 0,
            'patience': EARLY_STOPPING_PATIENCE,
            'minimum_epochs': EARLY_STOPPING_MIN_EPOCHS,
            'stopped_early': stopped_early,
            'completed_epochs': (
                int(history['epoch'][-1]) if history['epoch']
                else RESUME_AFTER_EPOCH if warm_start_info is not None else 0
            ),
            'best_epoch': checkpoint['epoch'],
            'model_selection_split': validation_split_key,
            'posthoc_validation_split': posthoc_validation_split_key,
            'posthoc_reserved_before_training': True,
        },
        'toxicity_bridge': toxicity_summary,
        'input_quality': input_quality_summary,
        'dataset': dataset_summary,
        'graph_cache': graph_cache.summary(),
        'split_manifest': split_manifest,
        'results': results,
        'candidate_explanations': explanation_summary,
        'latest_results_directory': str(LATEST_RESULTS_DIR) if PUBLISH_LATEST_RESULTS else None,
    })
    write_json(RUN_ARTIFACTS_DIR / 'run_manifest.json', manifest)
    print(f'Run artifacts saved to: {RUN_ARTIFACTS_DIR}')
    if PUBLISH_LATEST_RESULTS:
        latest_results_dir = publish_latest_results(RUN_ARTIFACTS_DIR)
        print(f'Latest results refreshed at: {latest_results_dir}')


if __name__ == '__main__':
    main()
